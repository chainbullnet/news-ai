<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class AINAP_Settings {

    const OPTION_KEY = 'ainap_settings';

    /**
     * Site niche presets — feeds, keywords, tone, categories
     */
    public static function get_presets() {
        return [
            'crypto' => [
                'label'           => '₿ Crypto / Blockchain',
                'rewrite_tone'    => 'authoritative',
                'target_word_count' => 900,
                'focus_keywords'  => 'Bitcoin, crypto, blockchain, DeFi, Web3, altcoin, NFT, cryptocurrency',
                'image_style'     => 'abstract',
                'max_posts_per_run' => 5,
                'run_interval'    => 'hourly',
                'categories'      => ['Markets','DeFi','NFT','Regulation','Technology','Exchanges','Bitcoin','Altcoins'],
                'feeds'           => [
                    // Tier 1 — Major outlets
                    'https://cointelegraph.com/rss',
                    'https://coindesk.com/arc/outboundfeeds/rss/',
                    'https://decrypt.co/feed',
                    'https://bitcoinmagazine.com/.rss/full/',
                    // Tier 2 — DeFi & Web3 focused
                    'https://thedefiant.io/feed',
                    'https://cryptoslate.com/feed/',
                    'https://cryptonews.com/news/feed/',
                    // Tier 3 — Broad coverage
                    'https://dailyhodl.com/feed/',
                    'https://news.bitcoin.com/feed/',
                    'https://ambcrypto.com/feed/',
                    // Reddit
                    'https://www.reddit.com/r/CryptoCurrency/.rss',
                    'https://www.reddit.com/r/Bitcoin/.rss',
                ],
            ],
            'tech' => [
                'label'           => '💻 Technology',
                'rewrite_tone'    => 'journalistic',
                'target_word_count' => 900,
                'focus_keywords'  => 'technology, AI, startup, innovation, software, gadgets',
                'image_style'     => 'photorealistic',
                'max_posts_per_run' => 5,
                'run_interval'    => 'hourly',
                'categories'      => ['AI','Startups','Gadgets','Software','Security','Science'],
                'feeds'           => [
                    'https://techcrunch.com/feed/',
                    'https://www.theverge.com/rss/index.xml',
                    'https://www.wired.com/feed/rss',
                    'https://feeds.arstechnica.com/arstechnica/index',
                    'https://www.engadget.com/rss.xml',
                    'https://feeds.feedburner.com/venturebeat/SZYF',
                ],
            ],
            'finance' => [
                'label'           => '📈 Finance / Business',
                'rewrite_tone'    => 'professional',
                'target_word_count' => 1000,
                'focus_keywords'  => 'stock market, investing, economy, finance, business, earnings',
                'image_style'     => 'photorealistic',
                'max_posts_per_run' => 4,
                'run_interval'    => 'hourly',
                'categories'      => ['Markets','Economy','Investing','Companies','Banking'],
                'feeds'           => [
                    'https://feeds.reuters.com/reuters/businessNews',
                    'https://feeds.bloomberg.com/markets/news.rss',
                    'https://www.ft.com/?format=rss',
                    'https://feeds.marketwatch.com/marketwatch/topstories/',
                    'https://finance.yahoo.com/news/rssindex',
                ],
            ],
            'general' => [
                'label'           => '🌐 General News',
                'rewrite_tone'    => 'journalistic',
                'target_word_count' => 800,
                'focus_keywords'  => 'news, latest, breaking, world, today',
                'image_style'     => 'photorealistic',
                'max_posts_per_run' => 3,
                'run_interval'    => 'hourly',
                'categories'      => ['World','Politics','Business','Technology','Sports'],
                'feeds'           => [
                    'https://feeds.bbci.co.uk/news/rss.xml',
                    'https://feeds.reuters.com/reuters/topNews',
                    'https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml',
                    'https://feeds.theguardian.com/theguardian/world/rss',
                    'https://rss.cnn.com/rss/edition.rss',
                ],
            ],
        ];
    }

    public static function get_all() {
        return get_option( self::OPTION_KEY, [] );
    }

    public static function get( $key, $default = '' ) {
        $settings = self::get_all();
        return $settings[ $key ] ?? $default;
    }

    public static function save( $data ) {
        $sanitized = [];

        $sanitized['anthropic_api_key']    = sanitize_text_field( $data['anthropic_api_key'] ?? '' );
        $sanitized['claude_model']         = sanitize_text_field( $data['claude_model'] ?? 'haiku' );
        $sanitized['stability_api_key']    = sanitize_text_field( $data['stability_api_key'] ?? '' );
        $sanitized['openai_api_key']       = sanitize_text_field( $data['openai_api_key'] ?? '' );
        $sanitized['gemini_api_key']       = sanitize_text_field( $data['gemini_api_key'] ?? '' );
        $sanitized['newsapi_key']          = sanitize_text_field( $data['newsapi_key'] ?? '' );
        $sanitized['image_provider']       = sanitize_text_field( $data['image_provider'] ?? 'pollinations' );
        $sanitized['openai_image_model']   = sanitize_text_field( $data['openai_image_model'] ?? 'dalle3' );
        $sanitized['default_category']     = intval( $data['default_category'] ?? 0 );
        $sanitized['default_author']       = intval( $data['default_author'] ?? 0 );
        $sanitized['max_posts_per_run']    = intval( $data['max_posts_per_run'] ?? 5 );
        $sanitized['run_interval']         = sanitize_text_field( $data['run_interval'] ?? 'hourly' );
        $sanitized['rewrite_tone']         = sanitize_text_field( $data['rewrite_tone'] ?? 'authoritative' );
        $sanitized['target_word_count']    = intval( $data['target_word_count'] ?? 900 );
        $sanitized['add_source_credit']    = (bool) ( $data['add_source_credit'] ?? true );
        $sanitized['auto_publish']         = (bool) ( $data['auto_publish'] ?? false );
        $sanitized['min_seo_score']        = intval( $data['min_seo_score'] ?? 60 );
        $sanitized['generate_images']      = (bool) ( $data['generate_images'] ?? true );
        $sanitized['image_style']          = sanitize_text_field( $data['image_style'] ?? 'abstract' );
        $sanitized['focus_keywords']       = sanitize_textarea_field( $data['focus_keywords'] ?? '' );
        $sanitized['active_niche']         = sanitize_text_field( $data['active_niche'] ?? 'crypto' );
        $sanitized['newsapi_topics']       = sanitize_textarea_field( $data['newsapi_topics'] ?? '' );
        $sanitized['enable_newsapi']       = (bool) ( $data['enable_newsapi'] ?? false );
        $sanitized['enable_reddit']        = (bool) ( $data['enable_reddit'] ?? true );
        $sanitized['freshness_minutes']    = intval( $data['freshness_minutes'] ?? 15 );
        $sanitized['check_title_dupes']    = (bool) ( $data['check_title_dupes'] ?? true );

        // Feeds - array of URLs
        $raw_feeds = $data['feeds'] ?? '';
        if ( is_string( $raw_feeds ) ) {
            $lines = explode( "\n", $raw_feeds );
        } else {
            $lines = (array) $raw_feeds;
        }
        $sanitized['feeds'] = array_filter( array_map( 'sanitize_url', array_map( 'trim', $lines ) ) );

        update_option( self::OPTION_KEY, $sanitized );
        return $sanitized;
    }

    /**
     * Apply a niche preset — overwrites content/feed settings, keeps API keys.
     */
    public static function apply_preset( $niche ) {
        $presets  = self::get_presets();
        if ( ! isset( $presets[ $niche ] ) ) return false;

        $preset   = $presets[ $niche ];
        $current  = self::get_all();

        // Preserve API keys and publishing prefs
        $merged = array_merge( $current, [
            'active_niche'      => $niche,
            'rewrite_tone'      => $preset['rewrite_tone'],
            'target_word_count' => $preset['target_word_count'],
            'focus_keywords'    => $preset['focus_keywords'],
            'image_style'       => $preset['image_style'],
            'max_posts_per_run' => $preset['max_posts_per_run'],
            'run_interval'      => $preset['run_interval'],
            'feeds'             => $preset['feeds'],
        ] );

        update_option( self::OPTION_KEY, $merged );

        // Auto-create WordPress categories for the niche
        if ( ! empty( $preset['categories'] ) ) {
            self::create_categories( $preset['categories'] );
        }

        return true;
    }

    /**
     * Create WP categories if they don't already exist.
     */
    public static function create_categories( $names ) {
        foreach ( $names as $name ) {
            if ( ! term_exists( $name, 'category' ) ) {
                wp_insert_term( $name, 'category' );
            }
        }
    }

    public static function set_defaults() {
        if ( ! get_option( self::OPTION_KEY ) ) {
            $crypto = self::get_presets()['crypto'];
            $defaults = [
                'anthropic_api_key'  => '',
                'claude_model'       => 'haiku',
                'stability_api_key'  => '',
                'openai_api_key'     => '',
                'gemini_api_key'     => '',
                'newsapi_key'        => '',
                'image_provider'     => 'pollinations',
                'openai_image_model' => 'dalle3',
                'default_category'   => 0,
                'default_author'     => 1,
                'max_posts_per_run'  => $crypto['max_posts_per_run'],
                'run_interval'       => 'every_15min',
                'rewrite_tone'       => $crypto['rewrite_tone'],
                'target_word_count'  => $crypto['target_word_count'],
                'add_source_credit'  => true,
                'auto_publish'       => false,
                'min_seo_score'      => 60,
                'generate_images'    => true,
                'image_style'        => $crypto['image_style'],
                'focus_keywords'     => $crypto['focus_keywords'],
                'active_niche'       => 'crypto',
                'enable_newsapi'     => false,
                'enable_reddit'      => true,
                'newsapi_topics'     => 'bitcoin,ethereum,cryptocurrency,blockchain,defi',
                'freshness_minutes'  => 15,
                'check_title_dupes'  => true,
                'feeds'              => $crypto['feeds'],
            ];
            update_option( self::OPTION_KEY, $defaults );
            // Create crypto categories automatically
            self::create_categories( $crypto['categories'] );
        }
    }
}
