<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class AINAP_SeoChecker {

    /**
     * Run SEO and AEO analysis on the rewritten article.
     *
     * @param array $article  Rewritten article data from Rewriter
     * @return array          Scores and detailed checks
     */
    public static function check( $article ) {
        $title           = $article['title'] ?? '';
        $meta_desc       = $article['meta_description'] ?? '';
        $content_html    = $article['content_html'] ?? '';
        $focus_keyphrase = $article['focus_keyphrase'] ?? '';
        $tags            = $article['tags'] ?? [];
        $faq             = $article['faq'] ?? [];

        $plain_content   = wp_strip_all_tags( $content_html );
        $word_count      = str_word_count( $plain_content );
        $content_lower   = strtolower( $plain_content );
        $title_lower     = strtolower( $title );
        $focus_lower     = strtolower( $focus_keyphrase );

        $seo_checks = [];
        $aeo_checks = [];
        $seo_score  = 0;
        $aeo_score  = 0;

        // ── SEO CHECKS ──────────────────────────────────────────────
        // 1. Title length (50–60 chars ideal)
        $title_len = strlen( $title );
        if ( $title_len >= 50 && $title_len <= 65 ) {
            $seo_checks[] = [ 'check' => 'Title length', 'status' => 'pass', 'detail' => "{$title_len} chars (ideal: 50-65)" ];
            $seo_score += 10;
        } elseif ( $title_len > 20 ) {
            $seo_checks[] = [ 'check' => 'Title length', 'status' => 'warn', 'detail' => "{$title_len} chars (ideal: 50-65)" ];
            $seo_score += 5;
        } else {
            $seo_checks[] = [ 'check' => 'Title length', 'status' => 'fail', 'detail' => "Too short: {$title_len} chars" ];
        }

        // 2. Focus keyphrase in title
        if ( ! empty( $focus_lower ) && strpos( $title_lower, $focus_lower ) !== false ) {
            $seo_checks[] = [ 'check' => 'Keyphrase in title', 'status' => 'pass', 'detail' => "Found '{$focus_keyphrase}' in title" ];
            $seo_score += 15;
        } elseif ( ! empty( $focus_lower ) ) {
            $seo_checks[] = [ 'check' => 'Keyphrase in title', 'status' => 'warn', 'detail' => "'{$focus_keyphrase}' not in title" ];
            $seo_score += 5;
        } else {
            $seo_checks[] = [ 'check' => 'Keyphrase in title', 'status' => 'warn', 'detail' => 'No focus keyphrase set' ];
            $seo_score += 3;
        }

        // 3. Meta description
        $meta_len = strlen( $meta_desc );
        if ( $meta_len >= 120 && $meta_len <= 160 ) {
            $seo_checks[] = [ 'check' => 'Meta description', 'status' => 'pass', 'detail' => "{$meta_len} chars (ideal: 120-160)" ];
            $seo_score += 10;
        } elseif ( $meta_len > 50 ) {
            $seo_checks[] = [ 'check' => 'Meta description', 'status' => 'warn', 'detail' => "{$meta_len} chars (ideal: 120-160)" ];
            $seo_score += 5;
        } else {
            $seo_checks[] = [ 'check' => 'Meta description', 'status' => 'fail', 'detail' => 'Missing or too short' ];
        }

        // 4. Word count
        if ( $word_count >= 800 ) {
            $seo_checks[] = [ 'check' => 'Word count', 'status' => 'pass', 'detail' => "{$word_count} words (min: 800)" ];
            $seo_score += 10;
        } elseif ( $word_count >= 500 ) {
            $seo_checks[] = [ 'check' => 'Word count', 'status' => 'warn', 'detail' => "{$word_count} words (min recommended: 800)" ];
            $seo_score += 5;
        } else {
            $seo_checks[] = [ 'check' => 'Word count', 'status' => 'fail', 'detail' => "Only {$word_count} words" ];
        }

        // 5. Keyphrase density (0.5%–2.5%)
        if ( ! empty( $focus_lower ) && $word_count > 0 ) {
            $kw_count = substr_count( $content_lower, $focus_lower );
            $density  = ( $kw_count / $word_count ) * 100;
            if ( $density >= 0.5 && $density <= 2.5 ) {
                $seo_checks[] = [ 'check' => 'Keyphrase density', 'status' => 'pass', 'detail' => round( $density, 2 ) . '% (ideal: 0.5%-2.5%)' ];
                $seo_score += 10;
            } elseif ( $density > 0 ) {
                $seo_checks[] = [ 'check' => 'Keyphrase density', 'status' => 'warn', 'detail' => round( $density, 2 ) . '% (ideal: 0.5%-2.5%)' ];
                $seo_score += 5;
            } else {
                $seo_checks[] = [ 'check' => 'Keyphrase density', 'status' => 'fail', 'detail' => 'Keyphrase not found in content' ];
            }
        }

        // 6. Headings (H2/H3)
        $h2_count = preg_match_all( '/<h2[^>]*>/i', $content_html );
        $h3_count = preg_match_all( '/<h3[^>]*>/i', $content_html );
        if ( $h2_count >= 2 ) {
            $seo_checks[] = [ 'check' => 'Subheadings (H2/H3)', 'status' => 'pass', 'detail' => "{$h2_count} H2s, {$h3_count} H3s" ];
            $seo_score += 10;
        } elseif ( $h2_count >= 1 ) {
            $seo_checks[] = [ 'check' => 'Subheadings (H2/H3)', 'status' => 'warn', 'detail' => "Only {$h2_count} H2 tag(s)" ];
            $seo_score += 5;
        } else {
            $seo_checks[] = [ 'check' => 'Subheadings (H2/H3)', 'status' => 'fail', 'detail' => 'No H2/H3 headings found' ];
        }

        // 7. Tags
        if ( count( $tags ) >= 3 ) {
            $seo_checks[] = [ 'check' => 'Tags/Keywords', 'status' => 'pass', 'detail' => count( $tags ) . ' tags assigned' ];
            $seo_score += 5;
        } else {
            $seo_checks[] = [ 'check' => 'Tags/Keywords', 'status' => 'warn', 'detail' => 'Fewer than 3 tags' ];
        }

        // 8. Keyphrase in first 100 words
        if ( ! empty( $focus_lower ) ) {
            $first_100 = implode( ' ', array_slice( explode( ' ', $content_lower ), 0, 100 ) );
            if ( strpos( $first_100, $focus_lower ) !== false ) {
                $seo_checks[] = [ 'check' => 'Keyphrase in intro', 'status' => 'pass', 'detail' => 'Found in first 100 words' ];
                $seo_score += 10;
            } else {
                $seo_checks[] = [ 'check' => 'Keyphrase in intro', 'status' => 'warn', 'detail' => 'Not in first 100 words' ];
            }
        }

        // ── AEO CHECKS (Answer Engine Optimization) ─────────────────
        // 1. FAQ Section
        if ( count( $faq ) >= 3 ) {
            $aeo_checks[] = [ 'check' => 'FAQ section', 'status' => 'pass', 'detail' => count( $faq ) . ' Q&A pairs (great for featured snippets)' ];
            $aeo_score += 30;
        } elseif ( count( $faq ) >= 1 ) {
            $aeo_checks[] = [ 'check' => 'FAQ section', 'status' => 'warn', 'detail' => 'Only ' . count( $faq ) . ' FAQ entries' ];
            $aeo_score += 10;
        } else {
            $aeo_checks[] = [ 'check' => 'FAQ section', 'status' => 'fail', 'detail' => 'No FAQ section found' ];
        }

        // 2. Direct answers (short paragraphs)
        $paragraphs    = preg_split( '/<\/p>/i', $content_html );
        $short_paras   = 0;
        foreach ( $paragraphs as $para ) {
            $wc = str_word_count( wp_strip_all_tags( $para ) );
            if ( $wc >= 40 && $wc <= 70 ) $short_paras++;
        }
        if ( $short_paras >= 2 ) {
            $aeo_checks[] = [ 'check' => 'Concise paragraphs', 'status' => 'pass', 'detail' => "{$short_paras} paragraphs in snippet-friendly range (40-70 words)" ];
            $aeo_score += 20;
        } else {
            $aeo_checks[] = [ 'check' => 'Concise paragraphs', 'status' => 'warn', 'detail' => 'Add 40-70 word paragraphs for featured snippets' ];
            $aeo_score += 5;
        }

        // 3. Question-style headings
        $question_h = preg_match_all( '/<h[23][^>]*>[^<]*\?[^<]*<\/h[23]>/i', $content_html );
        if ( $question_h >= 2 ) {
            $aeo_checks[] = [ 'check' => 'Question headings', 'status' => 'pass', 'detail' => "{$question_h} question-style H2/H3s (People Also Ask)" ];
            $aeo_score += 20;
        } elseif ( $question_h >= 1 ) {
            $aeo_checks[] = [ 'check' => 'Question headings', 'status' => 'warn', 'detail' => 'Consider more question-style headings' ];
            $aeo_score += 10;
        } else {
            $aeo_checks[] = [ 'check' => 'Question headings', 'status' => 'warn', 'detail' => 'No question headings found (add for People Also Ask)' ];
        }

        // 4. Structured data readiness
        if ( count( $faq ) >= 1 ) {
            $aeo_checks[] = [ 'check' => 'Schema markup ready', 'status' => 'pass', 'detail' => 'FAQ schema will be injected automatically' ];
            $aeo_score += 15;
        } else {
            $aeo_checks[] = [ 'check' => 'Schema markup ready', 'status' => 'fail', 'detail' => 'No FAQ = no FAQ schema' ];
        }

        // 5. Lists/tables
        $list_count = preg_match_all( '/<[uo]l/i', $content_html );
        if ( $list_count >= 1 ) {
            $aeo_checks[] = [ 'check' => 'Lists/structured data', 'status' => 'pass', 'detail' => "{$list_count} list element(s) found" ];
            $aeo_score += 15;
        } else {
            $aeo_checks[] = [ 'check' => 'Lists/structured data', 'status' => 'warn', 'detail' => 'No lists found — add bullet/numbered lists for snippets' ];
        }

        return [
            'seo_score'  => min( $seo_score, 100 ),
            'aeo_score'  => min( $aeo_score, 100 ),
            'seo_checks' => $seo_checks,
            'aeo_checks' => $aeo_checks,
        ];
    }
}
