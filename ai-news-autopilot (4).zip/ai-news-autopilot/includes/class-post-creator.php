<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AINAP_PostCreator {

    /**
     * Create a WordPress draft post from rewritten article data.
     */
    public static function create_draft( $article, $settings ) {
        $title           = sanitize_text_field( isset( $article['title'] )           ? $article['title']           : 'Untitled Article' );
        $content_html    = wp_kses_post( isset( $article['content_html'] )           ? $article['content_html']    : '' );
        $excerpt         = sanitize_textarea_field( isset( $article['excerpt'] )     ? $article['excerpt']         : '' );
        $tags            = isset( $article['tags'] )                                 ? $article['tags']            : array();
        $faq             = isset( $article['faq'] )                                  ? $article['faq']             : array();
        $meta_desc       = sanitize_text_field( isset( $article['meta_description'] )? $article['meta_description']: '' );
        $focus_keyphrase = sanitize_text_field( isset( $article['focus_keyphrase'] ) ? $article['focus_keyphrase'] : '' );
        $source_link     = esc_url_raw( isset( $article['source_link'] )             ? $article['source_link']     : '' );
        $seo_data        = isset( $article['seo_data'] )                             ? $article['seo_data']        : array();

        if ( ! empty( $faq ) ) {
            $content_html .= self::build_faq_html( $faq );
        }

        if ( ! empty( $source_link ) && ! empty( $settings['add_source_credit'] ) ) {
            $content_html .= '<p class="ainap-source-credit"><em>Source: <a href="' . esc_url( $source_link ) . '" target="_blank" rel="nofollow noopener">' . esc_html( $source_link ) . '</a></em></p>';
        }

        $post_status = ! empty( $settings['auto_publish'] ) ? 'publish' : 'draft';
        $min_seo     = intval( isset( $settings['min_seo_score'] ) ? $settings['min_seo_score'] : 60 );
        if ( ( isset( $seo_data['seo_score'] ) ? $seo_data['seo_score'] : 0 ) < $min_seo ) {
            $post_status = 'draft';
        }

        $post_data = array(
            'post_title'   => $title,
            'post_content' => $content_html,
            'post_excerpt' => $excerpt,
            'post_status'  => $post_status,
            'post_author'  => intval( isset( $settings['default_author'] ) ? $settings['default_author'] : 1 ),
            'post_type'    => 'post',
        );

        if ( ! empty( $settings['default_category'] ) && intval( $settings['default_category'] ) > 0 ) {
            $post_data['post_category'] = array( intval( $settings['default_category'] ) );
        }

        $post_id = wp_insert_post( $post_data, true );
        if ( is_wp_error( $post_id ) ) {
            return $post_id;
        }

        if ( ! empty( $tags ) ) {
            wp_set_post_tags( $post_id, $tags, false );
        }

        $image = isset( $article['image_url'] ) ? $article['image_url'] : null;
        if ( ! empty( $image['id'] ) ) {
            set_post_thumbnail( $post_id, intval( $image['id'] ) );
        }

        if ( ! empty( $meta_desc ) ) {
            update_post_meta( $post_id, '_yoast_wpseo_metadesc',   $meta_desc );
            update_post_meta( $post_id, 'rank_math_description',   $meta_desc );
            update_post_meta( $post_id, '_ainap_meta_description', $meta_desc );
        }
        if ( ! empty( $focus_keyphrase ) ) {
            update_post_meta( $post_id, '_yoast_wpseo_focuskw',    $focus_keyphrase );
            update_post_meta( $post_id, 'rank_math_focus_keyword', $focus_keyphrase );
            update_post_meta( $post_id, '_ainap_focus_keyphrase',  $focus_keyphrase );
        }

        update_post_meta( $post_id, '_ainap_source_url',  $source_link );
        update_post_meta( $post_id, '_ainap_seo_score',   isset( $seo_data['seo_score'] ) ? $seo_data['seo_score'] : 0 );
        update_post_meta( $post_id, '_ainap_aeo_score',   isset( $seo_data['aeo_score'] ) ? $seo_data['aeo_score'] : 0 );
        update_post_meta( $post_id, '_ainap_seo_data',    json_encode( $seo_data ) );
        // Flag: no image yet (will be updated after image generation)
        update_post_meta( $post_id, '_ainap_has_image',   0 );

        if ( ! empty( $faq ) ) {
            update_post_meta( $post_id, '_ainap_faq_schema', self::build_faq_schema( $faq, $title ) );
        }

        return $post_id;
    }

    /**
     * Attach a generated image to an existing post.
     * Used by the "Generate Image" button in history.
     */
    public static function attach_image( $post_id, $image_result ) {
        if ( empty( $image_result['id'] ) || ! $post_id ) {
            return false;
        }
        set_post_thumbnail( $post_id, intval( $image_result['id'] ) );
        update_post_meta( $post_id, '_ainap_has_image', 1 );
        return true;
    }

    /**
     * Check duplicate by source URL.
     */
    public static function source_exists( $url ) {
        if ( empty( $url ) ) return false;
        global $wpdb;
        $result = $wpdb->get_var( $wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_ainap_source_url' AND meta_value = %s LIMIT 1",
            $url
        ) );
        return ! empty( $result );
    }

    /**
     * Check duplicate by title similarity.
     * Returns true if a post with a very similar title already exists.
     */
    public static function title_exists( $title ) {
        if ( empty( $title ) ) return false;
        global $wpdb;
        // Exact match first
        $exact = $wpdb->get_var( $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_title = %s AND post_type = 'post' AND post_status != 'trash' LIMIT 1",
            $title
        ) );
        if ( ! empty( $exact ) ) return true;

        // Fuzzy: strip common words and check if 80%+ of words match an existing title
        $clean   = preg_replace( '/[^a-z0-9\s]/i', '', strtolower( $title ) );
        $words   = array_filter( explode( ' ', $clean ), function( $w ) { return strlen( $w ) > 4; } );
        if ( count( $words ) < 3 ) return false;

        // Check first 6 significant words as a phrase
        $phrase = implode( ' ', array_slice( $words, 0, 6 ) );
        $like   = '%' . $wpdb->esc_like( $phrase ) . '%';
        $result = $wpdb->get_var( $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE LOWER(post_title) LIKE %s AND post_type = 'post' AND post_status != 'trash' LIMIT 1",
            $like
        ) );
        return ! empty( $result );
    }

    private static function build_faq_html( $faq ) {
        $html  = '<div class="ainap-faq-section" itemscope itemtype="https://schema.org/FAQPage">';
        $html .= '<h2>Frequently Asked Questions</h2>';
        foreach ( $faq as $item ) {
            $q     = esc_html( isset( $item['question'] ) ? $item['question'] : '' );
            $a     = esc_html( isset( $item['answer'] )   ? $item['answer']   : '' );
            $html .= '<div class="ainap-faq-item" itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">';
            $html .= '<h3 itemprop="name">' . $q . '</h3>';
            $html .= '<div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">';
            $html .= '<p itemprop="text">' . $a . '</p></div></div>';
        }
        $html .= '</div>';
        return $html;
    }

    private static function build_faq_schema( $faq, $title ) {
        $entities = array();
        foreach ( $faq as $item ) {
            $entities[] = array(
                '@type'          => 'Question',
                'name'           => isset( $item['question'] ) ? $item['question'] : '',
                'acceptedAnswer' => array(
                    '@type' => 'Answer',
                    'text'  => isset( $item['answer'] ) ? $item['answer'] : '',
                ),
            );
        }
        return json_encode( array(
            '@context'   => 'https://schema.org',
            '@type'      => 'FAQPage',
            'name'       => $title,
            'mainEntity' => $entities,
        ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
    }
}

// Inject FAQ schema
add_action( 'wp_head', function () {
    if ( ! is_singular( 'post' ) ) return;
    $post_id = get_the_ID();
    $schema  = get_post_meta( $post_id, '_ainap_faq_schema', true );
    if ( ! empty( $schema ) ) {
        echo '<script type="application/ld+json">' . $schema . '</script>' . "\n";
    }
} );
