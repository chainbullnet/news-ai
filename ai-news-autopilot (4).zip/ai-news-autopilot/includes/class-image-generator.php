<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AINAP_ImageGenerator {

    /**
     * Generate a featured image for an article.
     *
     * Providers:
     *  - pollinations : Pollinations.ai (FREE, no key needed)
     *  - gemini       : Google Gemini Imagen 3 (~$0.02/image)
     *  - stability    : Stability AI SD3 (~$0.003/image)
     *  - openai       : OpenAI DALL-E 2/3 ($0.018–$0.04/image)
     *
     * Returns array ['id'=>attach_id, 'url'=>url] or WP_Error on failure.
     */
    public static function generate( $title, $content_html, $settings ) {
        if ( empty( $settings['generate_images'] ) ) {
            return null;
        }

        $provider = isset( $settings['image_provider'] ) ? $settings['image_provider'] : 'pollinations';
        $style    = isset( $settings['image_style'] )    ? $settings['image_style']    : 'abstract';
        $prompt   = self::build_prompt( $title, $content_html, $style );

        $image_data = null;
        $last_error = '';

        switch ( $provider ) {
            case 'gemini':
                $result = self::generate_gemini( $prompt, $settings );
                if ( is_wp_error( $result ) ) {
                    $last_error = $result->get_error_message();
                    // Fallback to Pollinations
                    $result2 = self::generate_pollinations( $prompt );
                    if ( ! is_wp_error( $result2 ) ) {
                        $image_data = $result2;
                        $last_error = '';
                    }
                } else {
                    $image_data = $result;
                }
                break;

            case 'openai':
                $result = self::generate_openai( $prompt, $settings );
                if ( is_wp_error( $result ) ) {
                    $last_error = $result->get_error_message();
                } else {
                    $image_data = $result;
                }
                break;

            case 'stability':
                $result = self::generate_stability( $prompt, $settings );
                if ( is_wp_error( $result ) ) {
                    $last_error = $result->get_error_message();
                    // Auto-fallback to Pollinations if Stability fails
                    $result2 = self::generate_pollinations( $prompt );
                    if ( ! is_wp_error( $result2 ) ) {
                        $image_data = $result2;
                        $last_error = '';
                    }
                } else {
                    $image_data = $result;
                }
                break;

            case 'pollinations':
            default:
                $result = self::generate_pollinations( $prompt );
                if ( is_wp_error( $result ) ) {
                    $last_error = $result->get_error_message();
                } else {
                    $image_data = $result;
                }
                break;
        }

        if ( empty( $image_data ) ) {
            return new WP_Error( 'image_failed', $last_error ?: 'Image generation returned no data.' );
        }

        $saved = self::save_to_media_library( $image_data['bytes'], $image_data['ext'], $title );
        if ( is_wp_error( $saved ) ) {
            return $saved;
        }
        if ( empty( $saved ) ) {
            return new WP_Error( 'image_save_failed', 'Failed to save image to WordPress media library.' );
        }

        return $saved;
    }

    /**
     * Build image generation prompt from article title + content.
     */
    private static function build_prompt( $title, $content_html, $style ) {
        $plain = wp_strip_all_tags( $content_html );
        $plain = substr( trim( $plain ), 0, 200 );

        $style_modifiers = array(
            'photorealistic' => 'photorealistic, high quality photo, professional photography, sharp focus, 4K',
            'illustration'   => 'digital illustration, editorial art style, vibrant colors, professional',
            'abstract'       => 'abstract digital art, geometric shapes, cryptocurrency blockchain theme, glowing neon accents on dark background, futuristic',
            'minimalist'     => 'minimalist flat design, clean simple composition, modern graphic design',
        );

        $modifier = isset( $style_modifiers[ $style ] ) ? $style_modifiers[ $style ] : $style_modifiers['abstract'];

        $prompt = "Professional news article featured image. Topic: {$title}. {$modifier}. No text overlay, no watermarks, no logos, no faces.";
        return $prompt;
    }

    /**
     * Google Gemini — Imagen 3 image generation (~$0.02/image).
     * Uses the Gemini API predict endpoint for Imagen 3.
     * Requires a Google AI API key with Imagen access enabled.
     */
    private static function generate_gemini( $prompt, $settings ) {
        $api_key = isset( $settings['gemini_api_key'] ) ? $settings['gemini_api_key'] : '';
        if ( empty( $api_key ) ) {
            return new WP_Error( 'no_gemini_key', 'Google Gemini API key not configured.' );
        }

        $endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/imagen-3.0-generate-002:predict?key=' . urlencode( $api_key );

        $response = wp_remote_post( $endpoint, array(
            'timeout' => 90,
            'headers' => array( 'Content-Type' => 'application/json' ),
            'body'    => json_encode( array(
                'instances' => array(
                    array( 'prompt' => $prompt ),
                ),
                'parameters' => array(
                    'sampleCount'  => 1,
                    'aspectRatio'  => '16:9',
                    'outputOptions' => array(
                        'mimeType' => 'image/jpeg',
                    ),
                ),
            ) ),
        ) );

        if ( is_wp_error( $response ) ) {
            return new WP_Error( 'gemini_request_failed', 'Gemini request failed: ' . $response->get_error_message() );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code !== 200 ) {
            $msg = isset( $body['error']['message'] ) ? $body['error']['message'] : "HTTP {$code}";
            return new WP_Error( 'gemini_http', "Gemini API error: {$msg}" );
        }

        // Response: predictions[0].bytesBase64Encoded
        $b64 = isset( $body['predictions'][0]['bytesBase64Encoded'] )
            ? $body['predictions'][0]['bytesBase64Encoded']
            : null;

        if ( empty( $b64 ) ) {
            // Some versions return mimeType + bytesBase64Encoded differently
            $b64 = isset( $body['predictions'][0]['image']['bytesBase64Encoded'] )
                ? $body['predictions'][0]['image']['bytesBase64Encoded']
                : null;
        }

        if ( empty( $b64 ) ) {
            return new WP_Error( 'gemini_empty', 'Gemini returned no image data. Check that Imagen API is enabled for your project.' );
        }

        $bytes = base64_decode( $b64 );
        if ( empty( $bytes ) || strlen( $bytes ) < 5000 ) {
            return new WP_Error( 'gemini_decode', 'Gemini image decode failed or image too small.' );
        }

        return array( 'bytes' => $bytes, 'ext' => 'jpg' );
    }

    /**
     * Pollinations.ai — FREE, no API key required.
     * Quality is lower but zero cost, great fallback.
     */
    private static function generate_pollinations( $prompt ) {
        $encoded  = urlencode( $prompt );
        // Use a seed for reproducibility, width/height for landscape
        $seed     = abs( crc32( $prompt ) ) % 999999;
        $url      = "https://image.pollinations.ai/prompt/{$encoded}?width=1200&height=675&seed={$seed}&nologo=true&enhance=true";

        $response = wp_remote_get( $url, array(
            'timeout'    => 60,
            'user-agent' => 'Mozilla/5.0 (compatible; WordPressBot/1.0)',
        ) );

        if ( is_wp_error( $response ) ) {
            return new WP_Error( 'pollinations_error', 'Pollinations request failed: ' . $response->get_error_message() );
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( $code !== 200 ) {
            return new WP_Error( 'pollinations_http', "Pollinations returned HTTP {$code}" );
        }

        $bytes = wp_remote_retrieve_body( $response );
        if ( empty( $bytes ) || strlen( $bytes ) < 5000 ) {
            return new WP_Error( 'pollinations_empty', 'Pollinations returned empty or too-small image.' );
        }

        // Verify it's actually an image
        $content_type = wp_remote_retrieve_header( $response, 'content-type' );
        if ( $content_type && strpos( $content_type, 'image' ) === false ) {
            return new WP_Error( 'pollinations_notimg', 'Pollinations did not return an image (got: ' . $content_type . ')' );
        }

        return array( 'bytes' => $bytes, 'ext' => 'jpg' );
    }

    /**
     * Stability AI — Stable Image Core API (v2beta, ~$0.003/image).
     * Updated to current working endpoint.
     */
    private static function generate_stability( $prompt, $settings ) {
        $api_key = isset( $settings['stability_api_key'] ) ? $settings['stability_api_key'] : '';
        if ( empty( $api_key ) ) {
            return new WP_Error( 'no_stability_key', 'Stability AI API key not configured.' );
        }

        // Use the current Stability AI REST API v2beta
        $response = wp_remote_post(
            'https://api.stability.ai/v2beta/stable-image/generate/core',
            array(
                'timeout' => 90,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $api_key,
                    'Accept'        => 'image/*',
                ),
                'body' => array(
                    'prompt'        => $prompt,
                    'output_format' => 'jpeg',
                    'aspect_ratio'  => '16:9',
                ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return new WP_Error( 'stability_error', 'Stability AI request failed: ' . $response->get_error_message() );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( $code !== 200 ) {
            // Try to extract error message
            $err = json_decode( $body, true );
            $msg = isset( $err['message'] ) ? $err['message'] : ( isset( $err['errors'][0] ) ? $err['errors'][0] : "HTTP {$code}" );
            return new WP_Error( 'stability_http', "Stability AI error: {$msg}" );
        }

        if ( empty( $body ) || strlen( $body ) < 5000 ) {
            return new WP_Error( 'stability_empty', 'Stability AI returned empty image.' );
        }

        return array( 'bytes' => $body, 'ext' => 'jpg' );
    }

    /**
     * OpenAI DALL-E 3 — ~$0.04/image (standard), ~$0.08/image (HD).
     */
    private static function generate_openai( $prompt, $settings ) {
        $api_key = isset( $settings['openai_api_key'] ) ? $settings['openai_api_key'] : '';
        if ( empty( $api_key ) ) {
            return new WP_Error( 'no_openai_key', 'OpenAI API key not configured.' );
        }

        // Use DALL-E 2 if openai_model setting is 'dalle2' (cheaper: $0.018/image)
        $use_dalle2 = ( isset( $settings['openai_image_model'] ) && $settings['openai_image_model'] === 'dalle2' );

        if ( $use_dalle2 ) {
            $req = array(
                'model'           => 'dall-e-2',
                'prompt'          => substr( $prompt, 0, 1000 ),
                'n'               => 1,
                'size'            => '1024x1024',
                'response_format' => 'b64_json',
            );
        } else {
            $req = array(
                'model'           => 'dall-e-3',
                'prompt'          => $prompt,
                'n'               => 1,
                'size'            => '1792x1024',
                'quality'         => 'standard',
                'response_format' => 'b64_json',
            );
        }

        $response = wp_remote_post( 'https://api.openai.com/v1/images/generations', array(
            'timeout' => 90,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
            ),
            'body' => json_encode( $req ),
        ) );

        if ( is_wp_error( $response ) ) {
            return new WP_Error( 'openai_error', 'OpenAI request failed: ' . $response->get_error_message() );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code !== 200 ) {
            $msg = isset( $body['error']['message'] ) ? $body['error']['message'] : "HTTP {$code}";
            return new WP_Error( 'openai_http', "OpenAI error: {$msg}" );
        }

        $b64 = isset( $body['data'][0]['b64_json'] ) ? $body['data'][0]['b64_json'] : null;
        if ( ! $b64 ) {
            return new WP_Error( 'openai_empty', 'OpenAI returned no image data.' );
        }

        $bytes = base64_decode( $b64 );
        if ( empty( $bytes ) ) {
            return new WP_Error( 'openai_decode', 'Failed to decode OpenAI image.' );
        }

        return array( 'bytes' => $bytes, 'ext' => 'png' );
    }

    /**
     * Save image bytes to WordPress media library.
     *
     * @param string $bytes  Raw image bytes
     * @param string $ext    File extension (jpg, png)
     * @param string $title  Post title (used as filename base)
     * @return array|WP_Error  ['id'=>int, 'url'=>string] or WP_Error
     */
    private static function save_to_media_library( $bytes, $ext, $title ) {
        if ( empty( $bytes ) ) {
            return new WP_Error( 'empty_bytes', 'No image bytes to save.' );
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $slug     = sanitize_file_name( strtolower( str_replace( ' ', '-', $title ) ) );
        $slug     = preg_replace( '/[^a-z0-9\-]/', '', $slug );
        $filename = substr( $slug, 0, 40 ) . '-' . time() . '.' . $ext;

        $upload = wp_upload_bits( $filename, null, $bytes );

        if ( ! empty( $upload['error'] ) ) {
            return new WP_Error( 'upload_error', 'wp_upload_bits error: ' . $upload['error'] );
        }

        $wp_filetype = wp_check_filetype( $filename, null );
        $attachment  = array(
            'post_mime_type' => $wp_filetype['type'],
            'post_title'     => sanitize_text_field( $title ),
            'post_content'   => '',
            'post_status'    => 'inherit',
        );

        $attach_id = wp_insert_attachment( $attachment, $upload['file'] );
        if ( is_wp_error( $attach_id ) ) {
            return $attach_id;
        }

        $attach_data = wp_generate_attachment_metadata( $attach_id, $upload['file'] );
        wp_update_attachment_metadata( $attach_id, $attach_data );

        return array(
            'id'  => $attach_id,
            'url' => $upload['url'],
        );
    }
}
