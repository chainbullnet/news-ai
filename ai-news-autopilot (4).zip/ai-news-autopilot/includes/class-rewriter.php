<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class AINAP_Rewriter {

    /**
     * Rewrite a scraped news item using Claude AI.
     *
     * @param array $item     Feed item data
     * @param array $settings Plugin settings
     * @return array|WP_Error  Rewritten article data
     */
    public static function rewrite( $item, $settings ) {
        $api_key = $settings['anthropic_api_key'] ?? '';
        if ( empty( $api_key ) ) {
            return new WP_Error( 'no_api_key', 'Anthropic API key not configured.' );
        }

        $tone           = $settings['rewrite_tone'] ?? 'authoritative';
        $word_count     = intval( $settings['target_word_count'] ?? 900 );
        $focus_keywords = $settings['focus_keywords'] ?? '';
        $niche          = $settings['active_niche'] ?? 'crypto';
        // Model selection: haiku = cheapest (~$0.001/article), sonnet = best quality (~$0.01/article)
        $model_pref     = $settings['claude_model'] ?? 'haiku';
        $model          = ( $model_pref === 'sonnet' ) ? 'claude-sonnet-4-6' : 'claude-haiku-4-5-20251001';

        $source_content = trim( $item['content'] ?? $item['description'] ?? '' );
        if ( strlen( $source_content ) < 50 ) {
            // Try scraping full article
            $scraped = AINAP_Scraper::scrape_article( $item['link'] ?? '' );
            if ( ! empty( $scraped ) ) {
                $source_content = $scraped;
            }
        }

        if ( empty( $source_content ) ) {
            return new WP_Error( 'no_content', 'Could not extract content from source.' );
        }

        $keyword_instruction = '';
        if ( ! empty( $focus_keywords ) ) {
            $keyword_instruction = "\n- Naturally incorporate these focus keywords where relevant: {$focus_keywords}";
        }

        $niche_contexts = [
            'crypto'  => "You write for a crypto/blockchain news audience. Use accurate terminology: DeFi, TVL, DEX, Layer 2, gas fees, wallets, market cap, bull/bear market, HODL, altcoins, etc. Be precise about price data and protocol names.",
            'tech'    => "You write for a technology news audience. Use accurate tech terminology and explain complex concepts accessibly.",
            'finance' => "You write for a finance/business audience. Use accurate financial terminology and maintain a professional, analytical tone.",
            'general' => "You write for a broad general news audience. Keep language accessible and engaging.",
        ];
        $niche_context = $niche_contexts[ $niche ] ?? $niche_contexts['general'];

        $prompt = <<<PROMPT
You are an expert journalist and SEO content writer specializing in {$niche} news. {$niche_context}

Your task is to rewrite the following news article as a completely fresh, original piece.

ORIGINAL TITLE: {$item['title']}
SOURCE CONTENT: {$source_content}

REQUIREMENTS:
- Rewrite in a {$tone} tone
- Target approximately {$word_count} words
- Create a compelling, SEO-optimized title (different from the original)
- Write a 160-character meta description
- Structure with proper H2/H3 subheadings
- Include a strong introduction and conclusion
- Write 5 relevant SEO tags/keywords
- Create a focus keyphrase (2-4 words)
- Write an FAQ section with 3 questions and answers (great for AEO/featured snippets){$keyword_instruction}
- Do NOT copy phrases verbatim from the source
- Do NOT include any source attribution in the body

Respond ONLY with a valid JSON object in this exact structure:
{
  "title": "New compelling title here",
  "meta_description": "160 char meta description",
  "focus_keyphrase": "main keyword phrase",
  "content_html": "<p>Full article in HTML with h2, h3, p tags...</p>",
  "excerpt": "2-3 sentence plain text excerpt",
  "tags": ["tag1", "tag2", "tag3", "tag4", "tag5"],
  "faq": [
    {"question": "Q1?", "answer": "A1."},
    {"question": "Q2?", "answer": "A2."},
    {"question": "Q3?", "answer": "A3."}
  ],
  "image_prompt": "Detailed DALL-E/Stable Diffusion image generation prompt relevant to this article"
}
PROMPT;

        $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', [
            'timeout' => 60,
            'headers' => [
                'x-api-key'         => $api_key,
                'anthropic-version' => '2023-06-01',
                'Content-Type'      => 'application/json',
            ],
            'body' => json_encode( [
                'model'      => $model,
                'max_tokens' => 4096,
                'messages'   => [
                    [ 'role' => 'user', 'content' => $prompt ],
                ],
            ] ),
        ] );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( $code !== 200 ) {
            $body = json_decode( wp_remote_retrieve_body( $response ), true );
            $msg  = $body['error']['message'] ?? "API error $code";
            return new WP_Error( 'api_error', $msg );
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        $text = $body['content'][0]['text'] ?? '';

        // Extract JSON from response
        $json_str = $text;
        if ( preg_match( '/```json\s*([\s\S]*?)\s*```/', $text, $m ) ) {
            $json_str = $m[1];
        } elseif ( preg_match( '/\{[\s\S]*\}/', $text, $m ) ) {
            $json_str = $m[0];
        }

        $article = json_decode( $json_str, true );
        if ( ! $article || empty( $article['title'] ) ) {
            return new WP_Error( 'parse_error', 'Failed to parse AI response as JSON.' );
        }

        return $article;
    }
}
