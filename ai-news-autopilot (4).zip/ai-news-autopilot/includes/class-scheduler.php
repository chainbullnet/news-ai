<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AINAP_Scheduler {

    public static function init() {
        add_filter( 'cron_schedules', array( __CLASS__, 'add_intervals' ) );
    }

    public static function add_intervals( $schedules ) {
        $schedules['ainap_every_15min'] = array(
            'interval' => 15 * MINUTE_IN_SECONDS,
            'display'  => __( 'Every 15 Minutes', 'ai-news-autopilot' ),
        );
        $schedules['ainap_every_30min'] = array(
            'interval' => 30 * MINUTE_IN_SECONDS,
            'display'  => __( 'Every 30 Minutes', 'ai-news-autopilot' ),
        );
        $schedules['ainap_every_2hours'] = array(
            'interval' => 2 * HOUR_IN_SECONDS,
            'display'  => __( 'Every 2 Hours', 'ai-news-autopilot' ),
        );
        $schedules['ainap_every_6hours'] = array(
            'interval' => 6 * HOUR_IN_SECONDS,
            'display'  => __( 'Every 6 Hours', 'ai-news-autopilot' ),
        );
        return $schedules;
    }

    public static function schedule() {
        if ( ! wp_next_scheduled( 'ainap_cron_hook' ) ) {
            $interval = AINAP_Settings::get( 'run_interval', 'ainap_every_15min' );
            wp_schedule_event( time(), self::map_interval( $interval ), 'ainap_cron_hook' );
        }
    }

    public static function unschedule() {
        $timestamp = wp_next_scheduled( 'ainap_cron_hook' );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, 'ainap_cron_hook' );
        }
    }

    public static function reschedule() {
        self::unschedule();
        self::schedule();
    }

    public static function map_interval( $interval ) {
        $map = array(
            'every_15min' => 'ainap_every_15min',
            'every_30min' => 'ainap_every_30min',
            'hourly'      => 'hourly',
            'every_2h'    => 'ainap_every_2hours',
            'every_6h'    => 'ainap_every_6hours',
            'twicedaily'  => 'twicedaily',
            'daily'       => 'daily',
        );
        return isset( $map[ $interval ] ) ? $map[ $interval ] : 'ainap_every_15min';
    }
}
