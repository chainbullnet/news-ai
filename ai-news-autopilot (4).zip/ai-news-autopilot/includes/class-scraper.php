<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AINAP_Scraper {

    /**
     * Fetch items from an RSS/Atom feed URL.
     *
     * @param string $feed_url
     * @param int    $limit
     * @param int    $max_age_minutes  Only return articles published within this many minutes. 0 = no filter.
     * @return array
     */
    public static function fetch_feed( $feed_url, $limit = 5, $max_age_minutes = 0 ) {
        $items = array();

        if ( ! function_exists( 'fetch_feed' ) ) {
            require_once ABSPATH . WPINC . '/feed.php';
        }

        $feed = fetch_feed( $feed_url );
        if ( is_wp_error( $feed ) ) {
            return $items;
        }

        $max        = $feed->get_item_quantity( $limit );
        $feed_items = $feed->get_items( 0, $max );
        $cutoff     = ( $max_age_minutes > 0 ) ? ( time() - ( $max_age_minutes * 60 ) ) : 0;

        foreach ( $feed_items as $item ) {

            // Freshness check
            if ( $cutoff > 0 ) {
                $pub_timestamp = $item->get_date( 'U' ); // Unix timestamp
                if ( $pub_timestamp && $pub_timestamp < $cutoff ) {
                    continue; // Article is older than allowed window — skip
                }
            }

            $content = $item->get_content();
            if ( empty( $content ) ) {
                $content = $item->get_description();
            }
            $plain_content = wp_strip_all_tags( $content );

            $image_url = '';
            $enclosure = $item->get_enclosure();
            if ( $enclosure ) {
                $image_url = $enclosure->get_link();
            }
            if ( empty( $image_url ) ) {
                $media = $item->get_item_tags( 'http://search.yahoo.com/mrss/', 'content' );
                if ( ! empty( $media[0]['attribs']['']['url'] ) ) {
                    $image_url = $media[0]['attribs']['']['url'];
                }
            }

            $items[] = array(
                'title'       => wp_strip_all_tags( $item->get_title() ),
                'link'        => esc_url_raw( $item->get_permalink() ),
                'description' => wp_strip_all_tags( $item->get_description() ),
                'content'     => $plain_content,
                'pub_date'    => $item->get_date( 'Y-m-d H:i:s' ),
                'pub_ts'      => $item->get_date( 'U' ),
                'author'      => $item->get_author() ? $item->get_author()->get_name() : '',
                'image'       => $image_url,
                'feed_url'    => $feed_url,
            );
        }

        return $items;
    }

    /**
     * Fetch from NewsAPI.org by keyword search.
     *
     * @param string $api_key
     * @param string $topics            Comma-separated keywords
     * @param int    $limit
     * @param int    $max_age_minutes   0 = no filter
     * @return array
     */
    public static function fetch_newsapi( $api_key, $topics, $limit = 5, $max_age_minutes = 0 ) {
        if ( empty( $api_key ) || empty( $topics ) ) {
            return array();
        }

        $items   = array();
        $query   = urlencode( trim( $topics ) );
        $from    = '';
        if ( $max_age_minutes > 0 ) {
            $from = '&from=' . gmdate( 'Y-m-d\TH:i:s\Z', time() - ( $max_age_minutes * 60 ) );
        }
        $endpoint = "https://newsapi.org/v2/everything?q={$query}&sortBy=publishedAt&pageSize={$limit}&language=en{$from}&apiKey={$api_key}";

        $response = wp_remote_get( $endpoint, array( 'timeout' => 15 ) );
        if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
            return $items;
        }

        $body     = json_decode( wp_remote_retrieve_body( $response ), true );
        $articles = isset( $body['articles'] ) ? $body['articles'] : array();

        foreach ( $articles as $a ) {
            $pub_ts = isset( $a['publishedAt'] ) ? strtotime( $a['publishedAt'] ) : 0;
            if ( $max_age_minutes > 0 && $pub_ts && $pub_ts < ( time() - $max_age_minutes * 60 ) ) {
                continue;
            }
            $source_name = isset( $a['source']['name'] ) ? $a['source']['name'] : '';
            $items[] = array(
                'title'       => wp_strip_all_tags( isset( $a['title'] )       ? $a['title']       : '' ),
                'link'        => esc_url_raw( isset( $a['url'] )               ? $a['url']         : '' ),
                'description' => wp_strip_all_tags( isset( $a['description'] ) ? $a['description'] : '' ),
                'content'     => wp_strip_all_tags( isset( $a['content'] )     ? $a['content']     : ( isset( $a['description'] ) ? $a['description'] : '' ) ),
                'pub_date'    => isset( $a['publishedAt'] ) ? $a['publishedAt'] : '',
                'pub_ts'      => $pub_ts,
                'author'      => isset( $a['author'] ) && ! empty( $a['author'] ) ? $a['author'] : $source_name,
                'image'       => isset( $a['urlToImage'] ) ? $a['urlToImage'] : '',
                'feed_url'    => 'newsapi:' . $topics,
            );
        }

        return $items;
    }

    /**
     * Scrape full article body from a URL.
     */
    public static function scrape_article( $url ) {
        if ( empty( $url ) ) return '';
        $response = wp_remote_get( $url, array(
            'timeout'    => 15,
            'user-agent' => 'Mozilla/5.0 (compatible; WordPressBot/1.0)',
        ) );
        if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
            return '';
        }
        $html     = wp_remote_retrieve_body( $response );
        $patterns = array(
            '/<article[^>]*>(.*?)<\/article>/si',
            '/<div[^>]*class="[^"]*article[^"]*"[^>]*>(.*?)<\/div>/si',
            '/<div[^>]*class="[^"]*content[^"]*"[^>]*>(.*?)<\/div>/si',
            '/<main[^>]*>(.*?)<\/main>/si',
        );
        foreach ( $patterns as $pattern ) {
            if ( preg_match( $pattern, $html, $matches ) ) {
                $text = wp_strip_all_tags( $matches[1] );
                $text = preg_replace( '/\s+/', ' ', $text );
                $text = trim( $text );
                if ( strlen( $text ) > 200 ) return $text;
            }
        }
        return '';
    }
}
