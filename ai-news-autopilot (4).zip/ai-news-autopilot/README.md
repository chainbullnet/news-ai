# AI News Autopilot — WordPress Plugin

**Auto-scrape → AI Rewrite → AI Image → SEO/AEO Check → WordPress Draft**

---

## Features

| Feature | Details |
|---|---|
| 📡 **Multi-feed scraping** | Add unlimited RSS/Atom feeds (BBC, Reuters, TechCrunch, etc.) |
| ✍️ **Claude AI rewriting** | Full article rewrite with new title, meta, structure — not a spin |
| 🎨 **AI image generation** | Stability AI (SDXL) or OpenAI (DALL-E 3) featured images |
| 📊 **SEO analysis** | Title length, keyphrase density, word count, headings, meta desc |
| 💡 **AEO analysis** | FAQ schema, featured snippet optimization, question headings |
| 💾 **WordPress drafts** | Saves as draft with featured image, tags, Yoast/RankMath meta |
| ⏱️ **Auto scheduling** | Every 30 min → daily via WP-Cron |
| 🔄 **Duplicate detection** | Skips already-imported source URLs |

---

## Installation

1. Upload the `ai-news-autopilot/` folder to `/wp-content/plugins/`
2. Activate via **Plugins → Installed Plugins**
3. Go to **AI News Autopilot → Settings**
4. Enter your **Anthropic API key** (required)
5. Optionally add Stability AI or OpenAI key for images
6. Add your RSS feed URLs
7. Click **Run Now** on the Dashboard to test

---

## API Keys Required

### Anthropic (Claude) — Required for rewriting
- Sign up: https://console.anthropic.com
- Used for: Article rewriting, SEO optimization, FAQ generation
- Model: `claude-opus-4-5`

### Stability AI — Optional (for SDXL images)
- Sign up: https://platform.stability.ai
- Used for: Featured image generation via Stable Diffusion XL

### OpenAI — Optional (for DALL-E 3 images)
- Sign up: https://platform.openai.com
- Used for: Featured image generation via DALL-E 3

---

## SEO Checks (scored /100)

- ✅ Title length (50-65 chars)
- ✅ Focus keyphrase in title
- ✅ Meta description (120-160 chars)
- ✅ Word count (800+ words)
- ✅ Keyphrase density (0.5%-2.5%)
- ✅ H2/H3 subheadings
- ✅ Tags/keywords assigned
- ✅ Keyphrase in intro paragraph

## AEO Checks (scored /100)

- ✅ FAQ section (3 Q&A pairs minimum)
- ✅ Concise paragraphs (40-70 words for featured snippets)
- ✅ Question-style H2/H3 headings
- ✅ FAQ JSON-LD schema auto-injected
- ✅ Lists/structured content

---

## Yoast / RankMath Compatibility

The plugin automatically sets:
- `_yoast_wpseo_metadesc` — Meta description
- `_yoast_wpseo_focuskw` — Focus keyphrase
- `rank_math_description` — RankMath meta
- `rank_math_focus_keyword` — RankMath keyphrase

---

## Directory Structure

```
ai-news-autopilot/
├── ai-news-autopilot.php       # Main plugin file
├── includes/
│   ├── class-settings.php      # Settings management
│   ├── class-scraper.php       # RSS feed scraping
│   ├── class-rewriter.php      # Claude AI rewriting
│   ├── class-image-generator.php  # AI image generation
│   ├── class-seo-checker.php   # SEO + AEO scoring
│   ├── class-post-creator.php  # WP draft creation
│   └── class-scheduler.php    # WP-Cron scheduling
├── admin/
│   ├── class-admin.php         # Admin menu
│   ├── admin.css               # Admin UI styles
│   ├── admin.js                # Admin UI scripts
│   └── views/
│       ├── dashboard.php       # Main dashboard
│       ├── settings.php        # Settings page
│       └── logs.php            # Run history
└── README.md
```

---

## Notes

- Duplicate articles are automatically filtered by source URL
- Articles below the minimum SEO score are always saved as draft
- FAQ JSON-LD schema is auto-injected into the `<head>` of each article
- All API calls use WP's `wp_remote_post` (no cURL dependency)
- Compatible with PHP 7.4+, WordPress 5.9+
