/* AI News Autopilot - Admin JS v1.2 */
jQuery(function ($) {
    'use strict';

    // ── Logging ────────────────────────────────────────────────────────────────
    function log(msg, type) {
        var out = $('#ainap-log-output');
        if (!out.length) return;
        var ts = new Date().toLocaleTimeString();
        out.append('<div class="ainap-log-' + (type || 'info') + '">[' + ts + '] ' + msg + '</div>');
        out[0].scrollTop = out[0].scrollHeight;
    }

    // ── Tabs ───────────────────────────────────────────────────────────────────
    $(document).on('click', '.ainap-tab', function () {
        var target = $(this).data('tab');
        $('.ainap-tab').removeClass('active');
        $('.ainap-tab-content').removeClass('active');
        $(this).addClass('active');
        $('#' + target).addClass('active');
    });

    // ── Run Now — Queue-based, one article at a time ───────────────────────────
    $(document).on('click', '#ainap-run-now', function () {
        var btn = $(this);
        btn.prop('disabled', true).html('<span class="ainap-spinner"></span> Fetching feeds...');
        $('#ainap-log-output').html('');
        log('Starting pipeline — fetching article queue from feeds...', 'info');

        // STEP 1: Fetch the queue (fast, no AI calls)
        $.ajax({
            url:  AINAP.ajax_url,
            type: 'POST',
            timeout: 30000,
            data: { action: 'ainap_fetch_queue', nonce: AINAP.nonce },
            success: function (res) {
                if (!res.success) {
                    log('Feed fetch error: ' + (res.data || 'Unknown'), 'error');
                    btn.prop('disabled', false).html('&#9654; Run Now');
                    return;
                }
                var queue = res.data.queue || [];
                var total = queue.length;

                if (total === 0) {
                    log('No new articles found within the last ' + res.data.freshness + ' min freshness window. (Skipped duplicates: ' + res.data.skipped_dupe + ')', 'warn');
                    btn.prop('disabled', false).html('&#9654; Run Now');
                    loadStats();
                    return;
                }

                log('Found ' + total + ' fresh article(s) (last ' + res.data.freshness + ' min) from ' + res.data.feeds_tried + ' feed(s). Skipped ' + res.data.skipped_dupe + ' duplicate(s). Rewriting one by one...', 'ok');
                btn.html('<span class="ainap-spinner"></span> Processing 0/' + total + '...');

                // STEP 2: Process each article one at a time
                processQueue(queue, 0, total, btn);
            },
            error: function (xhr) {
                log('Feed fetch failed: ' + xhr.statusText + ' (code ' + xhr.status + ')', 'error');
                btn.prop('disabled', false).html('&#9654; Run Now');
            }
        });
    });

    function processQueue(queue, index, total, btn) {
        if (index >= queue.length) {
            log('All done! ' + total + ' article(s) processed.', 'ok');
            btn.prop('disabled', false).html('&#9654; Run Now');
            loadStats();
            return;
        }

        var item  = queue[index];
        var count = index + 1;
        btn.html('<span class="ainap-spinner"></span> Rewriting ' + count + '/' + total + '...');
        log('[' + count + '/' + total + '] Rewriting: "' + item.title.substring(0, 60) + '"...', 'info');

        $.ajax({
            url:     AINAP.ajax_url,
            type:    'POST',
            timeout: 120000, // 2 min per article — enough for Claude API
            data: {
                action: 'ainap_process_one',
                nonce:  AINAP.nonce,
                item:   item
            },
            success: function (res) {
                if (res.success) {
                    var d = res.data;
                    if (d.status === 'skipped') {
                        log('[' + count + '/' + total + '] Skipped (already exists): ' + d.message, 'warn');
                    } else {
                        log('[' + count + '/' + total + '] ✓ Draft created: "' + d.title + '" — <a href="' + d.edit_url + '" target="_blank" style="color:var(--ainap-accent2)">Edit Post #' + d.post_id + '</a> | SEO: ' + d.seo_score + ' | AEO: ' + d.aeo_score, 'ok');
                    }
                } else {
                    var errMsg = (typeof res.data === 'object' && res.data.message) ? res.data.message : JSON.stringify(res.data);
                    log('[' + count + '/' + total + '] ✗ Error: ' + errMsg, 'error');
                }
                // Move to next article after short pause
                setTimeout(function () {
                    processQueue(queue, index + 1, total, btn);
                }, 1000);
            },
            error: function (xhr) {
                if (xhr.status === 0 || xhr.statusText === 'timeout') {
                    log('[' + count + '/' + total + '] Timeout — Claude API took too long. Skipping.', 'warn');
                } else {
                    log('[' + count + '/' + total + '] Request failed: ' + xhr.statusText, 'error');
                }
                setTimeout(function () {
                    processQueue(queue, index + 1, total, btn);
                }, 1000);
            }
        });
    }

    // ── Save Settings ──────────────────────────────────────────────────────────
    $(document).on('click', '#ainap-save-settings', function () {
        var btn = $(this);
        btn.prop('disabled', true).text('Saving...');

        var settings = {};
        $('[data-setting]').each(function () {
            var key = $(this).data('setting');
            if ($(this).is(':checkbox')) {
                settings[key] = $(this).is(':checked') ? 1 : 0;
            } else {
                settings[key] = $(this).val();
            }
        });

        $.ajax({
            url:  AINAP.ajax_url,
            type: 'POST',
            data: { action: 'ainap_save_settings', nonce: AINAP.nonce, settings: settings },
            success: function (res) {
                if (res.success) {
                    showNotice('Settings saved!', 'success');
                    var msg = $('#ainap-save-msg');
                    if (msg.length) { msg.show(); setTimeout(function () { msg.hide(); }, 2500); }
                } else {
                    showNotice('Error saving settings.', 'error');
                }
            },
            complete: function () {
                btn.prop('disabled', false).text('Save Settings');
            }
        });
    });

    // ── Test Feed ──────────────────────────────────────────────────────────────
    $(document).on('click', '#ainap-test-feed', function () {
        var url = $('#ainap-test-feed-url').val().trim();
        if (!url) return;
        var btn = $(this);
        btn.prop('disabled', true).text('Testing...');
        $('#ainap-feed-result').show().html('<em style="color:var(--ainap-muted)">Fetching...</em>');

        $.ajax({
            url:     AINAP.ajax_url,
            type:    'POST',
            timeout: 20000,
            data: { action: 'ainap_test_feed', nonce: AINAP.nonce, url: url },
            success: function (res) {
                if (res.success && res.data && res.data.length) {
                    var html = '<strong style="color:var(--ainap-success)">&#10003; Feed OK &mdash; ' + res.data.length + ' item(s):</strong><br><br>';
                    res.data.forEach(function (item, i) {
                        html += '<strong>' + (i + 1) + '. ' + esc(item.title) + '</strong><br>';
                        html += '<span style="color:var(--ainap-muted);font-size:11px">' + esc(item.link) + '</span><br><br>';
                    });
                    $('#ainap-feed-result').html(html);
                } else {
                    $('#ainap-feed-result').html('<span style="color:var(--ainap-danger)">&#10007; Could not fetch feed or no items found.</span>');
                }
            },
            error: function () {
                $('#ainap-feed-result').html('<span style="color:var(--ainap-danger)">&#10007; Request failed.</span>');
            },
            complete: function () { btn.prop('disabled', false).text('Test Feed'); }
        });
    });

    // ── Generate Image from history ────────────────────────────────────────────
    $(document).on('click', '.ainap-gen-img-btn', function () {
        var btn     = $(this);
        var postId  = btn.data('post-id');
        var origTxt = btn.text();
        btn.prop('disabled', true).text('Generating…');

        $.ajax({
            url:     AINAP.ajax_url,
            type:    'POST',
            timeout: 90000,
            data: { action: 'ainap_generate_image', nonce: AINAP.nonce, post_id: postId },
            success: function (res) {
                if (res.success) {
                    btn.replaceWith('<span style="color:var(--ainap-success);font-size:12px">&#10003; Done</span>');
                    var msg = $('#ainap-log-img-msg');
                    msg.text('Image generated for Post #' + postId).show();
                    setTimeout(function () { msg.hide(); }, 4000);
                } else {
                    btn.prop('disabled', false).text(origTxt);
                    alert('Image error: ' + (res.data || 'Unknown error'));
                }
            },
            error: function () {
                btn.prop('disabled', false).text(origTxt);
                alert('Request timed out or failed.');
            }
        });
    });

    // ── Load Logs ──────────────────────────────────────────────────────────────
    function loadLogs() {
        var tbody = $('#ainap-logs-table tbody');
        if (!tbody.length) return;
        tbody.html('<tr><td colspan="8" style="color:var(--ainap-muted);text-align:center;padding:24px">Loading...</td></tr>');

        $.ajax({
            url:  AINAP.ajax_url,
            type: 'POST',
            data: { action: 'ainap_get_logs', nonce: AINAP.nonce },
            success: function (res) {
                if (!res.success || !res.data || !res.data.length) {
                    tbody.html('<tr><td colspan="8" style="color:var(--ainap-muted);text-align:center;padding:24px">No runs yet. Click Run Now on the dashboard.</td></tr>');
                    return;
                }
                var rows = '';
                res.data.forEach(function (r) {
                    var cls    = r.status === 'draft_created' ? 'pass' : r.status === 'error' ? 'fail' : 'warn';
                    var postId = parseInt(r.post_id);
                    var link   = postId > 0
                        ? '<a href="/wp-admin/post.php?post=' + postId + '&action=edit" target="_blank" style="color:var(--ainap-accent)">#' + postId + '</a>'
                        : '&mdash;';
                    var imgCell = '&mdash;';
                    if (postId > 0 && r.status === 'draft_created') {
                        if (parseInt(r.has_image)) {
                            imgCell = '<span style="color:var(--ainap-success);font-size:12px">&#10003; Set</span>';
                        } else {
                            imgCell = '<button class="ainap-gen-img-btn ainap-btn ainap-btn-secondary" data-post-id="' + postId + '" style="padding:3px 10px;font-size:11px">&#127912; Generate</button>';
                        }
                    }
                    rows += '<tr>' +
                        '<td style="font-size:11px;color:var(--ainap-muted);white-space:nowrap">' + esc(r.run_time || '&mdash;') + '</td>' +
                        '<td style="font-size:12px">' + esc((r.original_title || '').substring(0, 52)) + (r.original_title && r.original_title.length > 52 ? '&hellip;' : '') + '</td>' +
                        '<td>' + (r.source_url ? '<a href="' + esc(r.source_url) + '" target="_blank" style="color:var(--ainap-muted);font-size:11px">Source &#8599;</a>' : '&mdash;') + '</td>' +
                        '<td><span class="ainap-status ainap-status-' + cls + '">' + r.status + '</span></td>' +
                        '<td>' + link + '</td>' +
                        '<td>' + scoreBar(r.seo_score) + '</td>' +
                        '<td>' + scoreBar(r.aeo_score) + '</td>' +
                        '<td>' + imgCell + '</td>' +
                        '</tr>';
                });
                tbody.html(rows);
            }
        });
    }

    function loadStats() {
        $.ajax({
            url:  AINAP.ajax_url,
            type: 'POST',
            data: { action: 'ainap_get_logs', nonce: AINAP.nonce },
            success: function (res) {
                if (!res.success || !res.data) return;
                var logs    = res.data;
                var total   = logs.length;
                var drafts  = logs.filter(function (l) { return l.status === 'draft_created'; }).length;
                var errors  = logs.filter(function (l) { return l.status === 'error'; }).length;
                var avgSeo  = total ? Math.round(logs.reduce(function (s, l) { return s + parseInt(l.seo_score || 0); }, 0) / total) : 0;
                $('#ainap-stat-total').text(total);
                $('#ainap-stat-drafts').text(drafts);
                $('#ainap-stat-errors').text(errors);
                $('#ainap-stat-seo').text(avgSeo);
            }
        });
    }

    function scoreBar(score) {
        var n   = parseInt(score) || 0;
        var cls = n >= 70 ? 'green' : n >= 40 ? 'yellow' : 'red';
        return '<div style="display:flex;align-items:center;gap:6px">' +
            '<span style="font-size:11px;font-family:\'IBM Plex Mono\',monospace;min-width:24px">' + n + '</span>' +
            '<div class="ainap-bar-wrap" style="width:52px"><div class="ainap-bar ainap-bar-' + cls + '" style="width:' + n + '%"></div></div>' +
            '</div>';
    }

    function showNotice(msg, type) {
        var cls    = type === 'success' ? 'notice-success' : 'notice-error';
        var notice = $('<div class="notice ' + cls + ' is-dismissible"><p>' + msg + '</p></div>');
        $('.ainap-wrap').prepend(notice);
        setTimeout(function () { notice.fadeOut(function () { notice.remove(); }); }, 3000);
    }

    function esc(str) {
        return String(str || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    // ── Preset apply ───────────────────────────────────────────────────────────
    $(document).on('click', '.ainap-preset-card', function () {
        var niche  = $(this).data('niche');
        var result = $('#ainap-preset-result');
        result.show().css('color', 'var(--ainap-muted)').text('Applying preset...');

        $.ajax({
            url:  AINAP.ajax_url,
            type: 'POST',
            data: { action: 'ainap_apply_preset', nonce: AINAP.nonce, niche: niche },
            success: function (res) {
                if (res.success) {
                    result.css('color', 'var(--ainap-success)').text('✓ ' + res.data.message);
                    $('#ainap-active-niche').val(niche);
                    var ta = $('#ainap-feeds-textarea');
                    if (ta.length && res.data.feeds) ta.val(res.data.feeds.join('\n'));
                    if (res.data.settings) {
                        var s = res.data.settings;
                        $.each(s, function (key, val) {
                            var el = $('[data-setting="' + key + '"]');
                            if (!el.length) return;
                            if (el.is(':checkbox')) el.prop('checked', !!parseInt(val));
                            else el.val(Array.isArray(val) ? val.join('\n') : (val || ''));
                        });
                    }
                    $('.ainap-preset-card').css({ borderColor: 'var(--ainap-border)', background: 'var(--ainap-surface2)' });
                    $('[data-niche="' + niche + '"]').css({ borderColor: 'var(--ainap-accent)', background: 'rgba(108,71,255,0.1)' });
                } else {
                    result.css('color', 'var(--ainap-danger)').text('✗ Error: ' + (res.data || 'Unknown'));
                }
            }
        });
    });

    // ── Init ───────────────────────────────────────────────────────────────────
    loadStats();
    if ($('#ainap-logs-table').length) loadLogs();
});
