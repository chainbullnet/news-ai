<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class AINAP_Admin {

    public static function init() {
        add_action( 'admin_menu',            [ __CLASS__, 'register_menu' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_assets' ] );
    }

    public static function register_menu() {
        add_menu_page(
            'AI News Autopilot',
            'AI News Autopilot',
            'manage_options',
            'ai-news-autopilot',
            [ __CLASS__, 'render_page' ],
            'dashicons-rss',
            30
        );
        add_submenu_page(
            'ai-news-autopilot',
            'Settings',
            'Settings',
            'manage_options',
            'ainap-settings',
            [ __CLASS__, 'render_settings_page' ]
        );
        add_submenu_page(
            'ai-news-autopilot',
            'Run History',
            'Run History',
            'manage_options',
            'ainap-logs',
            [ __CLASS__, 'render_logs_page' ]
        );
    }

    public static function enqueue_assets( $hook ) {
        if ( strpos( $hook, 'ai-news-autopilot' ) === false && strpos( $hook, 'ainap-' ) === false ) {
            return;
        }
        wp_enqueue_style(
            'ainap-admin',
            AINAP_PLUGIN_URL . 'admin/admin.css',
            [],
            AINAP_VERSION
        );
        wp_enqueue_script(
            'ainap-admin',
            AINAP_PLUGIN_URL . 'admin/admin.js',
            [ 'jquery' ],
            AINAP_VERSION,
            true
        );
        wp_localize_script( 'ainap-admin', 'AINAP', [
            'nonce'    => wp_create_nonce( 'ainap_nonce' ),
            'ajax_url' => admin_url( 'admin-ajax.php' ),
        ] );
    }

    public static function render_page() {
        $settings   = AINAP_Settings::get_all();
        $next_cron  = wp_next_scheduled( 'ainap_cron_hook' );
        $next_run   = $next_cron ? human_time_diff( $next_cron ) : 'Not scheduled';
        include AINAP_PLUGIN_DIR . 'admin/views/dashboard.php';
    }

    public static function render_settings_page() {
        $settings   = AINAP_Settings::get_all();
        $categories = get_categories( [ 'hide_empty' => false ] );
        $authors    = get_users( [ 'role__in' => [ 'administrator', 'editor', 'author' ] ] );
        include AINAP_PLUGIN_DIR . 'admin/views/settings.php';
    }

    public static function render_logs_page() {
        include AINAP_PLUGIN_DIR . 'admin/views/logs.php';
    }
}
