<?php if ( ! defined( 'ABSPATH' ) ) exit;
$presets      = AINAP_Settings::get_presets();
$active_niche = $settings['active_niche'] ?? 'crypto';
?>

<div class="ainap-wrap">

  <div class="ainap-header">
    <div class="ainap-header-icon">⚙️</div>
    <div>
      <h1>Plugin Settings</h1>
      <p>Configure AI providers, feeds, content rules, and scheduling</p>
    </div>
    <a href="<?php echo admin_url('admin.php?page=ai-news-autopilot'); ?>" class="ainap-btn ainap-btn-secondary">← Dashboard</a>
  </div>

  <!-- ── NICHE PRESET SWITCHER ──────────────────────────────────── -->
  <div class="ainap-section" style="margin-bottom:24px;border-color:rgba(108,71,255,0.5)">
    <div class="ainap-section-header" style="background:rgba(108,71,255,0.08)">
      <h3 class="ainap-section-title">🎯 Site Niche Preset</h3>
      <span style="font-size:12px;color:var(--ainap-muted)">One-click setup — loads feeds, keywords, tone &amp; creates WP categories automatically</span>
    </div>
    <div class="ainap-section-body">
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px;margin-bottom:16px">
        <?php foreach ( $presets as $key => $preset ) :
          $is_active = ( $active_niche === $key );
        ?>
          <div class="ainap-preset-card"
            data-niche="<?php echo esc_attr($key); ?>"
            style="padding:14px 16px;
            border:2px solid <?php echo $is_active ? 'var(--ainap-accent)' : 'var(--ainap-border)'; ?>;
            border-radius:10px;cursor:pointer;
            background:<?php echo $is_active ? 'rgba(108,71,255,0.1)' : 'var(--ainap-surface2)'; ?>;
            transition:all 0.2s">
            <div style="font-size:20px;margin-bottom:6px"><?php echo mb_substr($preset['label'],0,2); ?></div>
            <div style="font-size:13px;font-weight:600;color:var(--ainap-text)"><?php echo esc_html(trim(mb_substr($preset['label'],2))); ?></div>
            <div style="font-size:11px;color:var(--ainap-muted);margin-top:4px"><?php echo count($preset['feeds']); ?> feeds &middot; <?php echo $preset['max_posts_per_run']; ?>/run &middot; <?php echo $preset['rewrite_tone']; ?></div>
            <?php if ( $is_active ) : ?>
              <div style="font-size:10px;color:var(--ainap-accent);margin-top:6px;font-weight:700;text-transform:uppercase;letter-spacing:0.05em">✓ Active</div>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
      <div id="ainap-preset-result" style="display:none;padding:10px 14px;background:rgba(34,197,94,0.1);border:1px solid rgba(34,197,94,0.3);border-radius:8px;font-size:13px"></div>
      <p style="font-size:12px;color:var(--ainap-muted);margin:10px 0 0">⚡ Selecting a preset overwrites feeds &amp; content settings. Your API keys are never touched.</p>
    </div>
  </div>

  <div class="ainap-tabs">
    <button class="ainap-tab active" data-tab="tab-api">🔑 API Keys</button>
    <button class="ainap-tab" data-tab="tab-feeds">📡 News Feeds</button>
    <button class="ainap-tab" data-tab="tab-content">✍️ Content</button>
    <button class="ainap-tab" data-tab="tab-images">🎨 Images</button>
    <button class="ainap-tab" data-tab="tab-publish">📝 Publishing</button>
    <button class="ainap-tab" data-tab="tab-schedule">⏱️ Schedule</button>
  </div>

  <!-- ── API KEYS ──────────────────────────────────────────────── -->
  <div id="tab-api" class="ainap-tab-content active">
    <div class="ainap-section">
      <div class="ainap-section-header"><h3 class="ainap-section-title">AI &amp; Data Provider Keys</h3></div>
      <div class="ainap-section-body">
        <div class="ainap-form-grid">
          <div class="ainap-field ainap-form-full">
            <label>Anthropic (Claude) API Key <span style="color:var(--ainap-danger)">★ Required</span></label>
            <input type="password" data-setting="anthropic_api_key"
              value="<?php echo esc_attr( $settings['anthropic_api_key'] ?? '' ); ?>"
              placeholder="sk-ant-api03-...">
            <span class="ainap-hint">Powers article rewriting. Get yours at <a href="https://console.anthropic.com" target="_blank" style="color:var(--ainap-accent)">console.anthropic.com</a></span>
          </div>
          <div class="ainap-field ainap-form-full">
            <label>Claude Model</label>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:4px">
              <label style="display:flex;align-items:flex-start;gap:10px;padding:12px;border:1.5px solid <?php echo ($settings['claude_model']??'haiku')==='haiku'?'var(--ainap-accent)':'var(--ainap-border)'; ?>;border-radius:8px;cursor:pointer;background:<?php echo ($settings['claude_model']??'haiku')==='haiku'?'rgba(108,71,255,0.08)':'transparent'; ?>" id="ainap-model-haiku-label">
                <input type="radio" name="claude_model_pick" value="haiku" <?php checked($settings['claude_model']??'haiku','haiku'); ?> onchange="ainap_set_model('haiku')" style="margin-top:2px;width:auto">
                <div>
                  <div style="font-size:13px;font-weight:600;color:var(--ainap-text)">Claude Haiku <span style="color:var(--ainap-success);font-size:11px">⭐ Recommended</span></div>
                  <div style="font-size:11px;color:var(--ainap-muted);margin-top:3px">~$0.001/article &middot; Fast (5-10s) &middot; Great quality</div>
                  <div style="font-size:10px;color:var(--ainap-muted);margin-top:2px">Best value for bulk news rewriting</div>
                </div>
              </label>
              <label style="display:flex;align-items:flex-start;gap:10px;padding:12px;border:1.5px solid <?php echo ($settings['claude_model']??'haiku')==='sonnet'?'var(--ainap-accent)':'var(--ainap-border)'; ?>;border-radius:8px;cursor:pointer;background:<?php echo ($settings['claude_model']??'haiku')==='sonnet'?'rgba(108,71,255,0.08)':'transparent'; ?>" id="ainap-model-sonnet-label">
                <input type="radio" name="claude_model_pick" value="sonnet" <?php checked($settings['claude_model']??'haiku','sonnet'); ?> onchange="ainap_set_model('sonnet')" style="margin-top:2px;width:auto">
                <div>
                  <div style="font-size:13px;font-weight:600;color:var(--ainap-text)">Claude Sonnet</div>
                  <div style="font-size:11px;color:var(--ainap-muted);margin-top:3px">~$0.01/article &middot; Slower (15-25s) &middot; Best quality</div>
                  <div style="font-size:10px;color:var(--ainap-muted);margin-top:2px">Use for premium or long-form articles</div>
                </div>
              </label>
            </div>
            <input type="hidden" data-setting="claude_model" id="ainap-claude-model-val" value="<?php echo esc_attr($settings['claude_model']??'haiku'); ?>">
          </div>
          <script>
          function ainap_set_model(m) {
            document.getElementById('ainap-claude-model-val').value = m;
            var hl = document.getElementById('ainap-model-haiku-label');
            var sl = document.getElementById('ainap-model-sonnet-label');
            hl.style.borderColor = m==='haiku' ? 'var(--ainap-accent)' : 'var(--ainap-border)';
            sl.style.borderColor = m==='sonnet'? 'var(--ainap-accent)' : 'var(--ainap-border)';
            hl.style.background  = m==='haiku' ? 'rgba(108,71,255,0.08)' : 'transparent';
            sl.style.background  = m==='sonnet'? 'rgba(108,71,255,0.08)' : 'transparent';
          }
          </script>
          <div class="ainap-field">
            <label>Stability AI Key <span style="color:var(--ainap-muted)">(SD3 images ~$0.003)</span></label>
            <input type="password" data-setting="stability_api_key"
              value="<?php echo esc_attr( $settings['stability_api_key'] ?? '' ); ?>"
              placeholder="sk-...">
            <span class="ainap-hint"><a href="https://platform.stability.ai/" target="_blank" style="color:var(--ainap-accent)">platform.stability.ai</a></span>
          </div>
          <div class="ainap-field">
            <label>OpenAI Key <span style="color:var(--ainap-muted)">(DALL-E 2/3 images)</span></label>
            <input type="password" data-setting="openai_api_key"
              value="<?php echo esc_attr( $settings['openai_api_key'] ?? '' ); ?>"
              placeholder="sk-...">
            <span class="ainap-hint"><a href="https://platform.openai.com/" target="_blank" style="color:var(--ainap-accent)">platform.openai.com</a></span>
          </div>
          <div class="ainap-field">
            <label>Google Gemini Key <span style="color:var(--ainap-muted)">(Imagen 3 ~$0.02)</span></label>
            <input type="password" data-setting="gemini_api_key"
              value="<?php echo esc_attr( $settings['gemini_api_key'] ?? '' ); ?>"
              placeholder="AIza...">
            <span class="ainap-hint">Enable Imagen API in your project. <a href="https://aistudio.google.com/apikey" target="_blank" style="color:var(--ainap-accent)">aistudio.google.com/apikey</a></span>
          </div>
          <div class="ainap-field">
            <label>NewsAPI.org Key <span style="color:var(--ainap-muted)">(keyword news search)</span></label>
            <input type="password" data-setting="newsapi_key"
              value="<?php echo esc_attr( $settings['newsapi_key'] ?? '' ); ?>"
              placeholder="abc123def456...">
            <span class="ainap-hint">Free: 100 req/day &middot; Paid: unlimited. <a href="https://newsapi.org/register" target="_blank" style="color:var(--ainap-accent)">newsapi.org/register</a></span>
          </div>
          <div class="ainap-field ainap-form-full">
            <label style="color:var(--ainap-muted);font-size:11px">Image provider is configured in the 🎨 Images tab below.</label>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ── NEWS FEEDS ────────────────────────────────────────────── -->
  <div id="tab-feeds" class="ainap-tab-content">

    <div class="ainap-section">
      <div class="ainap-section-header"><h3 class="ainap-section-title">NewsAPI.org — Keyword Search</h3></div>
      <div class="ainap-section-body">
        <div class="ainap-toggle-row">
          <div class="ainap-toggle-info">
            <div class="ainap-toggle-label">Enable NewsAPI (keyword-based news)</div>
            <div class="ainap-toggle-desc">Fetch articles from 150,000+ sources by search term — supplements RSS feeds</div>
          </div>
          <label class="ainap-switch">
            <input type="checkbox" data-setting="enable_newsapi" <?php checked( !empty($settings['enable_newsapi']) ); ?>>
            <span class="ainap-switch-slider"></span>
          </label>
        </div>
        <div class="ainap-field" style="margin-top:14px">
          <label>NewsAPI Topics / Keywords</label>
          <input type="text" data-setting="newsapi_topics"
            value="<?php echo esc_attr( $settings['newsapi_topics'] ?? 'bitcoin,ethereum,cryptocurrency,blockchain,defi' ); ?>"
            placeholder="bitcoin, ethereum, cryptocurrency, blockchain, DeFi, NFT">
          <span class="ainap-hint">Comma-separated. NewsAPI searches news headlines from all providers for these terms.</span>
        </div>
      </div>
    </div>

    <div class="ainap-section">
      <div class="ainap-section-header">
        <h3 class="ainap-section-title">RSS / Atom Feed URLs</h3>
        <span style="font-size:12px;color:var(--ainap-muted)"><?php echo count($settings['feeds'] ?? []); ?> feeds loaded</span>
      </div>
      <div class="ainap-section-body">

        <?php
        $crypto_groups = [
          '📰 Major Crypto Outlets' => [
            'CoinTelegraph'  => 'https://cointelegraph.com/rss',
            'CoinDesk'       => 'https://coindesk.com/arc/outboundfeeds/rss/',
            'Decrypt'        => 'https://decrypt.co/feed',
            'Bitcoin Mag'    => 'https://bitcoinmagazine.com/.rss/full/',
            'CryptoNews'     => 'https://cryptonews.com/news/feed/',
            'CryptoSlate'    => 'https://cryptoslate.com/feed/',
            'Daily HODL'     => 'https://dailyhodl.com/feed/',
            'Bitcoin.com'    => 'https://news.bitcoin.com/feed/',
            'AMBCrypto'      => 'https://ambcrypto.com/feed/',
          ],
          '⚡ DeFi &amp; Web3' => [
            'The Defiant'    => 'https://thedefiant.io/feed',
            'Bankless'       => 'https://banklesshq.com/rss/',
            'DeFi Prime'     => 'https://defiprime.com/feed.xml',
          ],
          '💬 Reddit Crypto' => [
            'r/CryptoCurrency' => 'https://www.reddit.com/r/CryptoCurrency/.rss',
            'r/Bitcoin'        => 'https://www.reddit.com/r/Bitcoin/.rss',
            'r/ethereum'       => 'https://www.reddit.com/r/ethereum/.rss',
            'r/defi'           => 'https://www.reddit.com/r/defi/.rss',
            'r/NFT'            => 'https://www.reddit.com/r/NFT/.rss',
            'r/altcoin'        => 'https://www.reddit.com/r/altcoin/.rss',
          ],
          '🏛️ Regulation &amp; Macro' => [
            'Reuters Crypto'   => 'https://feeds.reuters.com/reuters/cryptoNews',
            'Reuters Business' => 'https://feeds.reuters.com/reuters/businessNews',
            'Bloomberg Crypto' => 'https://feeds.bloomberg.com/crypto/news.rss',
          ],
          '🌐 General Tech/Finance' => [
            'TechCrunch'  => 'https://techcrunch.com/feed/',
            'The Verge'   => 'https://www.theverge.com/rss/index.xml',
            'Yahoo Finance'=> 'https://finance.yahoo.com/news/rssindex',
          ],
        ];
        ?>

        <div style="margin-bottom:20px">
          <div style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--ainap-muted);margin-bottom:12px">
            Click any source below to add it to your feed list ↓
          </div>
          <?php foreach ( $crypto_groups as $group_name => $group_feeds ) : ?>
            <div style="margin-bottom:14px">
              <div style="font-size:12px;color:var(--ainap-accent2);margin-bottom:7px;font-weight:600"><?php echo $group_name; ?></div>
              <div style="display:flex;flex-wrap:wrap;gap:6px">
                <?php foreach ( $group_feeds as $name => $url ) : ?>
                  <span class="ainap-feed-chip"
                    data-url="<?php echo esc_attr($url); ?>"
                    style="font-size:11px;padding:4px 10px;border-radius:4px;cursor:pointer;
                    background:var(--ainap-surface2);border:1px solid var(--ainap-border);
                    color:var(--ainap-muted);transition:all 0.15s;user-select:none"
                    onclick="ainap_add_feed('<?php echo esc_js($url); ?>', this)"
                    title="<?php echo esc_attr($url); ?>">
                    + <?php echo esc_html($name); ?>
                  </span>
                <?php endforeach; ?>
              </div>
            </div>
          <?php endforeach; ?>
        </div>

        <div class="ainap-field">
          <label>Active Feed URLs <span style="color:var(--ainap-muted);font-weight:400">(one per line — edit freely)</span></label>
          <textarea id="ainap-feeds-textarea" data-setting="feeds"
            style="min-height:220px;font-family:'IBM Plex Mono',monospace;font-size:12px;line-height:1.8"><?php
            echo esc_textarea( implode( "\n", (array)($settings['feeds'] ?? []) ) );
          ?></textarea>
          <span class="ainap-hint">Each line = one RSS/Atom feed URL. Duplicates are automatically skipped during processing.</span>
        </div>

        <div style="margin-top:16px;padding:16px;background:var(--ainap-surface2);border-radius:8px;border:1px solid var(--ainap-border)">
          <strong style="font-size:13px">🔍 Test a Feed URL:</strong>
          <div style="display:flex;gap:10px;margin-top:10px">
            <input type="text" id="ainap-test-feed-url" placeholder="https://cointelegraph.com/rss"
              style="flex:1;background:var(--ainap-bg);border:1px solid var(--ainap-border);border-radius:8px;padding:10px;color:var(--ainap-text);font-size:13px">
            <button id="ainap-test-feed" class="ainap-btn ainap-btn-secondary">Test Feed</button>
          </div>
          <div id="ainap-feed-result" class="ainap-feed-test-result" style="display:none;margin-top:12px"></div>
        </div>
      </div>
    </div>
  </div>

  <!-- ── CONTENT ───────────────────────────────────────────────── -->
  <div id="tab-content" class="ainap-tab-content">
    <div class="ainap-section">
      <div class="ainap-section-header"><h3 class="ainap-section-title">Content Rewriting Rules</h3></div>
      <div class="ainap-section-body">
        <div class="ainap-form-grid">
          <div class="ainap-field">
            <label>Writing Tone</label>
            <select data-setting="rewrite_tone">
              <?php foreach ( ['authoritative','journalistic','professional','conversational','formal','casual'] as $t ) : ?>
                <option value="<?php echo $t; ?>" <?php selected( $settings['rewrite_tone'] ?? 'authoritative', $t ); ?>><?php echo ucfirst($t); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="ainap-field">
            <label>Target Word Count</label>
            <input type="number" data-setting="target_word_count" min="300" max="3000" step="50"
              value="<?php echo esc_attr( $settings['target_word_count'] ?? 900 ); ?>">
            <span class="ainap-hint">800–1000 recommended for crypto (readers want fast facts)</span>
          </div>
          <div class="ainap-field ainap-form-full">
            <label>Global Focus Keywords</label>
            <input type="text" data-setting="focus_keywords"
              value="<?php echo esc_attr( $settings['focus_keywords'] ?? '' ); ?>"
              placeholder="Bitcoin, crypto, blockchain, DeFi, Web3, altcoin, NFT, cryptocurrency">
            <span class="ainap-hint">Claude naturally incorporates these into every article.</span>
          </div>
          <div class="ainap-field">
            <label>Minimum SEO Score to Publish</label>
            <input type="number" data-setting="min_seo_score" min="0" max="100"
              value="<?php echo esc_attr( $settings['min_seo_score'] ?? 60 ); ?>">
            <span class="ainap-hint">Articles below this are always saved as draft.</span>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ── IMAGES ────────────────────────────────────────────────── -->
  <div id="tab-images" class="ainap-tab-content">
    <div class="ainap-section">
      <div class="ainap-section-header"><h3 class="ainap-section-title">AI Image Generation</h3></div>
      <div class="ainap-section-body">
        <div class="ainap-toggle-row">
          <div class="ainap-toggle-info">
            <div class="ainap-toggle-label">Enable AI Image Generation</div>
            <div class="ainap-toggle-desc">Auto-generate a relevant featured image for each article</div>
          </div>
          <label class="ainap-switch">
            <input type="checkbox" data-setting="generate_images" <?php checked( !empty($settings['generate_images']) ); ?>>
            <span class="ainap-switch-slider"></span>
          </label>
        </div>

        <div style="margin-top:16px;display:grid;grid-template-columns:1fr 1fr;gap:14px">
          <div class="ainap-field">
            <label>Image Provider</label>
            <select data-setting="image_provider" id="ainap-img-provider-sel" onchange="ainap_toggle_img_opts()">
              <option value="pollinations" <?php selected( $settings['image_provider'] ?? 'pollinations', 'pollinations' ); ?>>Pollinations.ai — FREE ⭐</option>
              <option value="gemini"       <?php selected( $settings['image_provider'] ?? 'pollinations', 'gemini' ); ?>>Google Gemini Imagen 3 — ~$0.02/image</option>
              <option value="stability"    <?php selected( $settings['image_provider'] ?? 'pollinations', 'stability' ); ?>>Stability AI SD3 — ~$0.003/image</option>
              <option value="openai"       <?php selected( $settings['image_provider'] ?? 'pollinations', 'openai' ); ?>>OpenAI DALL-E — $0.018–$0.04/image</option>
            </select>
            <span class="ainap-hint" id="ainap-img-hint">No API key needed. Stability AI and Gemini fall back to Pollinations automatically if they fail.</span>
          </div>
          <div class="ainap-field" id="ainap-dalle-model-row" style="display:<?php echo (($settings['image_provider']??'pollinations')==='openai')?'flex':'none'; ?>;flex-direction:column;gap:6px">
            <label>DALL-E Model</label>
            <select data-setting="openai_image_model">
              <option value="dalle3" <?php selected( $settings['openai_image_model'] ?? 'dalle3', 'dalle3' ); ?>>DALL-E 3 — $0.04/image (best quality)</option>
              <option value="dalle2" <?php selected( $settings['openai_image_model'] ?? 'dalle3', 'dalle2' ); ?>>DALL-E 2 — $0.018/image (cheaper)</option>
            </select>
          </div>
          <div class="ainap-field">
            <label>Image Style</label>
            <select data-setting="image_style">
              <?php foreach ([
                'abstract'       => 'Abstract — best for crypto',
                'photorealistic' => 'Photorealistic',
                'illustration'   => 'Digital Illustration',
                'minimalist'     => 'Minimalist',
              ] as $val => $label ) : ?>
                <option value="<?php echo $val; ?>" <?php selected( $settings['image_style'] ?? 'abstract', $val ); ?>><?php echo $label; ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <!-- Cost comparison -->
        <div style="margin-top:16px;padding:14px;background:var(--ainap-surface2);border:1px solid var(--ainap-border);border-radius:8px">
          <strong style="font-size:12px;color:var(--ainap-muted);text-transform:uppercase;letter-spacing:0.06em">Image Provider Comparison</strong>
          <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:10px">
            <div style="text-align:center;padding:10px;background:rgba(34,197,94,0.08);border:1px solid rgba(34,197,94,0.3);border-radius:8px">
              <div style="font-size:16px;font-weight:700;color:var(--ainap-success)">FREE</div>
              <div style="font-size:11px;color:var(--ainap-muted);margin-top:3px">Pollinations</div>
              <div style="font-size:10px;color:var(--ainap-muted)">No key needed</div>
            </div>
            <div style="text-align:center;padding:10px;background:rgba(245,158,11,0.08);border:1px solid rgba(245,158,11,0.3);border-radius:8px">
              <div style="font-size:16px;font-weight:700;color:var(--ainap-warn)">$0.003</div>
              <div style="font-size:11px;color:var(--ainap-muted);margin-top:3px">Stability AI</div>
              <div style="font-size:10px;color:var(--ainap-muted)">Best value paid</div>
            </div>
            <div style="text-align:center;padding:10px;background:rgba(26,115,232,0.08);border:1px solid rgba(26,115,232,0.3);border-radius:8px">
              <div style="font-size:16px;font-weight:700;color:#1a73e8">$0.02</div>
              <div style="font-size:11px;color:var(--ainap-muted);margin-top:3px">Gemini Imagen 3</div>
              <div style="font-size:10px;color:var(--ainap-muted)">Google quality</div>
            </div>
            <div style="text-align:center;padding:10px;background:rgba(108,71,255,0.08);border:1px solid rgba(108,71,255,0.3);border-radius:8px">
              <div style="font-size:16px;font-weight:700;color:var(--ainap-accent)">$0.04</div>
              <div style="font-size:11px;color:var(--ainap-muted);margin-top:3px">DALL-E 3</div>
              <div style="font-size:10px;color:var(--ainap-muted)">Highest quality</div>
            </div>
          </div>
        </div>

        <script>
        function ainap_toggle_img_opts() {
          var sel = document.getElementById('ainap-img-provider-sel');
          var dalleRow = document.getElementById('ainap-dalle-model-row');
          var hint = document.getElementById('ainap-img-hint');
          var hints = {
            pollinations: 'No API key needed. Free and unlimited. Other providers fall back to this automatically on failure.',
            gemini:       'Requires Google Gemini API key (API Keys tab). Falls back to Pollinations if it fails.',
            stability:    'Requires Stability AI key (API Keys tab). Falls back to Pollinations if it fails.',
            openai:       'Requires OpenAI key (API Keys tab). DALL-E 2 is cheaper; DALL-E 3 has better quality.'
          };
          dalleRow.style.display = sel.value === 'openai' ? 'flex' : 'none';
          hint.textContent = hints[sel.value] || '';
        }
        </script>
      </div>
    </div>
  </div>

  <!-- ── PUBLISHING ────────────────────────────────────────────── -->
  <div id="tab-publish" class="ainap-tab-content">
    <div class="ainap-section">
      <div class="ainap-section-header"><h3 class="ainap-section-title">Publishing Options</h3></div>
      <div class="ainap-section-body">
        <div class="ainap-toggle-row">
          <div class="ainap-toggle-info">
            <div class="ainap-toggle-label">Auto-Publish (Skip Draft Review)</div>
            <div class="ainap-toggle-desc">⚠️ Publishes immediately without human review. Only enable with min SEO score ≥ 70.</div>
          </div>
          <label class="ainap-switch">
            <input type="checkbox" data-setting="auto_publish" <?php checked( !empty($settings['auto_publish']) ); ?>>
            <span class="ainap-switch-slider"></span>
          </label>
        </div>
        <div class="ainap-toggle-row">
          <div class="ainap-toggle-info">
            <div class="ainap-toggle-label">Add Source Credit</div>
            <div class="ainap-toggle-desc">Append a "Source:" attribution link at the bottom of each article</div>
          </div>
          <label class="ainap-switch">
            <input type="checkbox" data-setting="add_source_credit" <?php checked( !empty($settings['add_source_credit']) ); ?>>
            <span class="ainap-switch-slider"></span>
          </label>
        </div>
        <div class="ainap-form-grid" style="margin-top:20px">
          <div class="ainap-field">
            <label>Default Category</label>
            <select data-setting="default_category">
              <option value="0">— Uncategorized —</option>
              <?php foreach ( $categories as $cat ) : ?>
                <option value="<?php echo $cat->term_id; ?>" <?php selected( $settings['default_category'] ?? 0, $cat->term_id ); ?>><?php echo esc_html($cat->name); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="ainap-field">
            <label>Default Author</label>
            <select data-setting="default_author">
              <?php foreach ( $authors as $user ) : ?>
                <option value="<?php echo $user->ID; ?>" <?php selected( $settings['default_author'] ?? 1, $user->ID ); ?>><?php echo esc_html($user->display_name); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ── SCHEDULE ──────────────────────────────────────────────── -->
  <div id="tab-schedule" class="ainap-tab-content">
    <div class="ainap-section">
      <div class="ainap-section-header"><h3 class="ainap-section-title">Automation Schedule</h3></div>
      <div class="ainap-section-body">
        <div class="ainap-form-grid">
          <div class="ainap-field">
            <label>Run Interval</label>
            <select data-setting="run_interval" id="ainap-interval-sel">
              <option value="every_15min" <?php selected( $settings['run_interval'] ?? 'every_15min', 'every_15min' ); ?>>Every 15 Minutes ⭐</option>
              <option value="every_30min" <?php selected( $settings['run_interval'] ?? 'every_15min', 'every_30min' ); ?>>Every 30 Minutes</option>
              <option value="hourly"      <?php selected( $settings['run_interval'] ?? 'every_15min', 'hourly' ); ?>>Every Hour</option>
              <option value="every_2h"   <?php selected( $settings['run_interval'] ?? 'every_15min', 'every_2h' ); ?>>Every 2 Hours</option>
              <option value="every_6h"   <?php selected( $settings['run_interval'] ?? 'every_15min', 'every_6h' ); ?>>Every 6 Hours</option>
              <option value="twicedaily" <?php selected( $settings['run_interval'] ?? 'every_15min', 'twicedaily' ); ?>>Twice Daily</option>
              <option value="daily"      <?php selected( $settings['run_interval'] ?? 'every_15min', 'daily' ); ?>>Once Daily</option>
            </select>
          </div>
          <div class="ainap-field">
            <label>Max Articles Per Run</label>
            <input type="number" id="ainap-max-articles" data-setting="max_posts_per_run" min="1" max="20"
              value="<?php echo esc_attr( $settings['max_posts_per_run'] ?? 5 ); ?>">
            <span class="ainap-hint">Keep at 3–5 to avoid Claude API rate limits</span>
          </div>
          <div class="ainap-field">
            <label>Freshness Window (minutes)</label>
            <input type="number" data-setting="freshness_minutes" min="0" max="1440"
              value="<?php echo esc_attr( $settings['freshness_minutes'] ?? 15 ); ?>">
            <span class="ainap-hint">Only fetch articles published within this window. <strong>0</strong> = no filter (fetch any age).</span>
          </div>
          <div class="ainap-field">
            <div class="ainap-toggle-row" style="border:none;padding-top:8px">
              <div class="ainap-toggle-info">
                <div class="ainap-toggle-label">Skip duplicate titles</div>
                <div class="ainap-toggle-desc">Skip if a similar title already exists in WP — catches same story from multiple sources</div>
              </div>
              <label class="ainap-switch" style="margin-left:16px;flex-shrink:0">
                <input type="checkbox" data-setting="check_title_dupes" <?php checked( isset($settings['check_title_dupes']) ? $settings['check_title_dupes'] : true ); ?>>
                <span class="ainap-switch-slider"></span>
              </label>
            </div>
          </div>
        </div>

        <!-- Daily calculator -->
        <div style="margin-top:16px;padding:14px;background:rgba(108,71,255,0.08);border:1px solid rgba(108,71,255,0.3);border-radius:8px">
          <strong style="font-size:13px">📊 Daily Output Estimate</strong>
          <div id="ainap-calc" style="font-size:14px;color:var(--ainap-muted);margin-top:8px">—</div>
        </div>

        <!-- Cron tip -->
        <div style="margin-top:14px;padding:14px;background:var(--ainap-surface2);border:1px solid var(--ainap-border);border-radius:8px">
          <strong style="font-size:13px">🔧 True Server Cron (Recommended)</strong>
          <p style="font-size:12px;color:var(--ainap-muted);margin:8px 0 4px">WP-Cron only fires when someone visits your site. For guaranteed hourly runs, add this to cPanel Cron Jobs:</p>
          <code style="display:block;background:var(--ainap-bg);padding:10px 12px;border-radius:6px;font-size:12px;color:var(--ainap-accent2);word-break:break-all">* * * * * curl -s <?php echo esc_url(site_url('/wp-cron.php?doing_wp_cron')); ?> &gt; /dev/null 2&gt;&amp;1</code>
        </div>
      </div>
    </div>
  </div>

  <!-- Save -->
  <div style="margin-top:20px;display:flex;justify-content:flex-end;gap:12px;align-items:center">
    <input type="hidden" data-setting="active_niche" id="ainap-active-niche" value="<?php echo esc_attr($active_niche); ?>">
    <span id="ainap-save-msg" style="font-size:13px;color:var(--ainap-success);display:none">✓ Saved!</span>
    <button id="ainap-save-settings" class="ainap-btn ainap-btn-primary" style="padding:12px 32px;font-size:15px">
      💾 Save Settings
    </button>
  </div>

</div>

<script>
// ── Feed chip helper
function ainap_add_feed(url, el) {
  var ta = document.getElementById('ainap-feeds-textarea');
  var lines = ta.value.split('\n').map(function(l){return l.trim();}).filter(Boolean);
  if (lines.indexOf(url) === -1) {
    ta.value = lines.join('\n') + (lines.length ? '\n' : '') + url;
    el.style.background = 'rgba(34,197,94,0.15)';
    el.style.borderColor = '#22c55e';
    el.style.color = '#22c55e';
  } else {
    el.style.background = 'rgba(245,158,11,0.15)';
    el.style.borderColor = '#f59e0b';
    el.style.color = '#f59e0b';
    el.title = 'Already in list';
  }
}

// ── Daily calculator
function ainap_calc() {
  var sel = document.getElementById('ainap-interval-sel');
  var max = document.getElementById('ainap-max-articles');
  if (!sel || !max) return;
  var hours = {every_30min:0.5,hourly:1,every_2h:2,every_6h:6,twicedaily:12,daily:24};
  var h = hours[sel.value] || 1;
  var m = parseInt(max.value) || 5;
  var runsDay = 24 / h;
  var daily = Math.round(runsDay * m);
  var monthly = daily * 30;
  document.getElementById('ainap-calc').innerHTML =
    '<strong style="color:var(--ainap-text)">' + Math.round(runsDay) + ' runs/day</strong>' +
    ' &times; <strong style="color:var(--ainap-text)">' + m + ' articles</strong>' +
    ' = <strong style="color:var(--ainap-accent2);font-size:16px">' + daily + ' articles/day</strong>' +
    ' &nbsp;&middot;&nbsp; <span style="color:var(--ainap-muted)">~' + monthly.toLocaleString() + '/month</span>';
}
document.addEventListener('change', ainap_calc);
ainap_calc();

// ── Niche preset click
document.querySelectorAll('.ainap-preset-card').forEach(function(card) {
  card.addEventListener('click', function() {
    var niche = this.dataset.niche;
    var result = document.getElementById('ainap-preset-result');
    result.style.display = 'block';
    result.style.color = 'var(--ainap-muted)';
    result.style.background = 'rgba(108,71,255,0.08)';
    result.style.borderColor = 'rgba(108,71,255,0.3)';
    result.textContent = 'Applying preset...';

    jQuery.ajax({
      url: AINAP.ajax_url, type: 'POST',
      data: { action: 'ainap_apply_preset', nonce: AINAP.nonce, niche: niche },
      success: function(res) {
        if (res.success) {
          result.style.color = 'var(--ainap-success)';
          result.style.background = 'rgba(34,197,94,0.1)';
          result.style.borderColor = 'rgba(34,197,94,0.3)';
          result.innerHTML = '✓ ' + res.data.message;
          document.getElementById('ainap-active-niche').value = niche;
          // Update feeds textarea
          var ta = document.getElementById('ainap-feeds-textarea');
          if (ta && res.data.feeds) ta.value = res.data.feeds.join('\n');
          // Update other fields
          if (res.data.settings) {
            var s = res.data.settings;
            Object.keys(s).forEach(function(key) {
              var el = document.querySelector('[data-setting="'+key+'"]');
              if (!el) return;
              if (el.type === 'checkbox') el.checked = !!parseInt(s[key]);
              else el.value = Array.isArray(s[key]) ? s[key].join('\n') : (s[key] || '');
            });
          }
          // Highlight active card
          document.querySelectorAll('.ainap-preset-card').forEach(function(c) {
            c.style.borderColor = 'var(--ainap-border)';
            c.style.background = 'var(--ainap-surface2)';
            var badge = c.querySelector('.ainap-preset-active');
            if (badge) badge.remove();
          });
          card.style.borderColor = 'var(--ainap-accent)';
          card.style.background = 'rgba(108,71,255,0.1)';
          ainap_calc();
        } else {
          result.style.color = 'var(--ainap-danger)';
          result.textContent = '✗ Error: ' + (res.data || 'Unknown');
        }
      }
    });
  });
});

// Test feed — show result area
var testBtn = document.getElementById('ainap-test-feed');
if (testBtn) testBtn.addEventListener('click', function() {
  document.getElementById('ainap-feed-result').style.display = 'block';
});

// Save success flash
jQuery(document).on('ainap:saved', function() {
  var msg = document.getElementById('ainap-save-msg');
  if (msg) { msg.style.display='inline'; setTimeout(function(){msg.style.display='none';}, 2500); }
});
</script>
