<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="ainap-wrap">

  <div class="ainap-header">
    <div class="ainap-header-icon">🤖</div>
    <div>
      <h1>AI News Autopilot</h1>
      <p>Scrape → Rewrite → Image → SEO/AEO → Draft</p>
    </div>
    <span class="ainap-version-badge">v<?php echo AINAP_VERSION; ?></span>
  </div>

  <!-- Stats cards -->
  <div class="ainap-cards">
    <div class="ainap-card">
      <div class="ainap-card-value" id="ainap-stat-total">—</div>
      <div class="ainap-card-label">Total Runs</div>
      <div class="ainap-card-sub">All time articles processed</div>
    </div>
    <div class="ainap-card">
      <div class="ainap-card-value" id="ainap-stat-drafts" style="color:var(--ainap-accent2)">—</div>
      <div class="ainap-card-label">Drafts Created</div>
      <div class="ainap-card-sub">Saved to WordPress</div>
    </div>
    <div class="ainap-card">
      <div class="ainap-card-value" id="ainap-stat-seo" style="color:var(--ainap-warn)">—</div>
      <div class="ainap-card-label">Avg SEO Score</div>
      <div class="ainap-card-sub">Across all articles</div>
    </div>
    <div class="ainap-card">
      <div class="ainap-card-value" id="ainap-stat-errors" style="color:var(--ainap-danger)">—</div>
      <div class="ainap-card-label">Errors</div>
      <div class="ainap-card-sub">Failed runs</div>
    </div>
  </div>

  <!-- Run panel -->
  <div class="ainap-run-panel">
    <div>
      <div style="font-size:24px;margin-bottom:4px">⚡</div>
    </div>
    <div class="ainap-run-panel-text">
      <h2>Run Pipeline Now</h2>
      <p>Next scheduled run in: <strong style="color:var(--ainap-accent2)"><?php echo esc_html( $next_run ); ?></strong>
        &nbsp;·&nbsp; Interval: <strong><?php echo esc_html( AINAP_Settings::get('run_interval','hourly') ); ?></strong>
        &nbsp;·&nbsp; Max per run: <strong><?php echo esc_html( AINAP_Settings::get('max_posts_per_run',3) ); ?></strong>
      </p>
    </div>
    <div class="ainap-run-panel-actions">
      <a href="<?php echo admin_url('edit.php?post_status=draft&post_type=post'); ?>" class="ainap-btn ainap-btn-secondary" target="_blank">
        📝 View Drafts
      </a>
      <button id="ainap-run-now" class="ainap-btn ainap-btn-primary">▶ Run Now</button>
    </div>
  </div>

  <!-- Log output -->
  <div class="ainap-section">
    <div class="ainap-section-header">
      <h3 class="ainap-section-title">Live Output</h3>
      <button class="ainap-btn ainap-btn-secondary" style="padding:5px 12px;font-size:12px"
        onclick="document.getElementById('ainap-log-output').innerHTML=''">Clear</button>
    </div>
    <div class="ainap-section-body" style="padding:16px">
      <div id="ainap-log-output">Waiting for run...</div>
    </div>
  </div>

  <!-- Pipeline diagram -->
  <div class="ainap-section">
    <div class="ainap-section-header">
      <h3 class="ainap-section-title">Pipeline Overview</h3>
    </div>
    <div class="ainap-section-body">
      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
        <?php
        $steps = [
          ['icon' => '📡', 'label' => 'RSS Scrape',    'color' => '#6c47ff'],
          ['icon' => '🔍', 'label' => 'Extract',       'color' => '#6c47ff'],
          ['icon' => '✍️',  'label' => 'AI Rewrite',   'color' => '#00d4aa'],
          ['icon' => '🎨', 'label' => 'AI Image',      'color' => '#00d4aa'],
          ['icon' => '📊', 'label' => 'SEO Check',     'color' => '#f59e0b'],
          ['icon' => '💡', 'label' => 'AEO Check',     'color' => '#f59e0b'],
          ['icon' => '💾', 'label' => 'Save Draft',    'color' => '#22c55e'],
        ];
        foreach ( $steps as $i => $step ) : ?>
          <div style="display:flex;align-items:center;gap:6px">
            <div style="background:<?php echo $step['color']; ?>22;border:1px solid <?php echo $step['color']; ?>66;
              border-radius:8px;padding:8px 12px;font-size:13px;font-weight:600;color:<?php echo $step['color']; ?>">
              <?php echo $step['icon']; ?> <?php echo $step['label']; ?>
            </div>
            <?php if ( $i < count($steps)-1 ) : ?><span style="color:var(--ainap-muted)">→</span><?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- Active feeds -->
  <div class="ainap-section">
    <div class="ainap-section-header">
      <h3 class="ainap-section-title">Active News Feeds</h3>
      <a href="<?php echo admin_url('admin.php?page=ainap-settings'); ?>" class="ainap-btn ainap-btn-secondary" style="padding:5px 14px;font-size:12px">Manage →</a>
    </div>
    <div class="ainap-section-body">
      <?php $feeds = AINAP_Settings::get( 'feeds', [] ); ?>
      <?php if ( empty( $feeds ) ) : ?>
        <p style="color:var(--ainap-muted)">No feeds configured. <a href="<?php echo admin_url('admin.php?page=ainap-settings'); ?>" style="color:var(--ainap-accent)">Add feeds →</a></p>
      <?php else : ?>
        <div style="display:flex;flex-direction:column;gap:8px">
          <?php foreach ( $feeds as $feed ) : ?>
            <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:var(--ainap-surface2);border-radius:8px;border:1px solid var(--ainap-border)">
              <span style="font-size:16px">📡</span>
              <span style="font-size:13px;color:var(--ainap-text)"><?php echo esc_html( $feed ); ?></span>
              <span class="ainap-status ainap-status-pass" style="margin-left:auto">Active</span>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>

</div>
