<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="ainap-wrap">

  <div class="ainap-header">
    <div class="ainap-header-icon">📋</div>
    <div>
      <h1>Run History</h1>
      <p>All articles processed by AI News Autopilot</p>
    </div>
    <a href="<?php echo admin_url('admin.php?page=ai-news-autopilot'); ?>" class="ainap-btn ainap-btn-secondary">← Dashboard</a>
  </div>

  <div class="ainap-section">
    <div class="ainap-section-header">
      <h3 class="ainap-section-title">Processing Log</h3>
      <div style="display:flex;gap:8px;align-items:center">
        <span id="ainap-log-img-msg" style="font-size:12px;color:var(--ainap-success);display:none"></span>
        <button class="ainap-btn ainap-btn-secondary" style="padding:5px 12px;font-size:12px" onclick="location.reload()">↻ Refresh</button>
      </div>
    </div>
    <div class="ainap-section-body" style="padding:0">
      <div class="ainap-table-wrap">
        <table class="ainap-table" id="ainap-logs-table">
          <thead>
            <tr>
              <th>Time</th>
              <th>Original Title</th>
              <th>Source</th>
              <th>Status</th>
              <th>Post</th>
              <th>SEO</th>
              <th>AEO</th>
              <th>Image</th>
            </tr>
          </thead>
          <tbody>
            <tr><td colspan="8" style="color:var(--ainap-muted);text-align:center;padding:32px">Loading...</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div style="margin-top:12px;padding:14px;background:rgba(108,71,255,0.08);border:1px solid rgba(108,71,255,0.3);border-radius:var(--ainap-radius)">
    <strong style="font-size:13px">💡 Generate Image</strong>
    <p style="font-size:12px;color:var(--ainap-muted);margin:6px 0 0">
      Articles without a featured image show a <strong style="color:var(--ainap-warn)">Generate Image</strong> button.
      This calls your configured image API (Stability AI or DALL-E 3) and sets it as the featured image automatically.
      Requires an image API key in Settings → API Keys.
    </p>
  </div>

</div>
