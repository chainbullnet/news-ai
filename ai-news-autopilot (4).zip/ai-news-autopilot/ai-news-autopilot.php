<?php
/**
 * Plugin Name: AI News Autopilot
 * Plugin URI:  https://github.com/your-repo/ai-news-autopilot
 * Description: Auto-scrapes crypto/news RSS feeds, rewrites with Claude AI, generates AI images, runs SEO/AEO checks, and saves as WordPress drafts.
 * Version:     1.3.0
 * Author:      AI News Autopilot
 * License:     GPL v2 or later
 * Text Domain: ai-news-autopilot
 * Requires at least: 5.9
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'AINAP_VERSION',    '1.3.0' );
define( 'AINAP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'AINAP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once AINAP_PLUGIN_DIR . 'includes/class-settings.php';
require_once AINAP_PLUGIN_DIR . 'includes/class-scraper.php';
require_once AINAP_PLUGIN_DIR . 'includes/class-rewriter.php';
require_once AINAP_PLUGIN_DIR . 'includes/class-image-generator.php';
require_once AINAP_PLUGIN_DIR . 'includes/class-seo-checker.php';
require_once AINAP_PLUGIN_DIR . 'includes/class-post-creator.php';
require_once AINAP_PLUGIN_DIR . 'includes/class-scheduler.php';
require_once AINAP_PLUGIN_DIR . 'admin/class-admin.php';

add_action( 'plugins_loaded', array( 'AINAP_Admin',     'init' ) );
add_action( 'plugins_loaded', array( 'AINAP_Scheduler', 'init' ) );

register_activation_hook( __FILE__,   'ainap_activate' );
register_deactivation_hook( __FILE__, 'ainap_deactivate' );

function ainap_activate() {
    AINAP_Settings::set_defaults();
    AINAP_Scheduler::schedule();
    ainap_create_table();
}

function ainap_deactivate() {
    AINAP_Scheduler::unschedule();
}

function ainap_create_table() {
    global $wpdb;
    $table           = $wpdb->prefix . 'ainap_logs';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS {$table} (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        run_time datetime DEFAULT NULL,
        source_url varchar(500) DEFAULT '',
        original_title text DEFAULT NULL,
        status varchar(50) DEFAULT 'pending',
        post_id bigint(20) DEFAULT 0,
        seo_score int(3) DEFAULT 0,
        aeo_score int(3) DEFAULT 0,
        error_message text DEFAULT NULL,
        PRIMARY KEY (id)
    ) {$charset_collate};";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );
}

// ── AJAX ─────────────────────────────────────────────────────────────────────
add_action( 'wp_ajax_ainap_fetch_queue',    'ainap_ajax_fetch_queue' );
add_action( 'wp_ajax_ainap_process_one',    'ainap_ajax_process_one' );
add_action( 'wp_ajax_ainap_generate_image', 'ainap_ajax_generate_image' );
add_action( 'wp_ajax_ainap_get_logs',       'ainap_ajax_get_logs' );
add_action( 'wp_ajax_ainap_save_settings',  'ainap_ajax_save_settings' );
add_action( 'wp_ajax_ainap_test_feed',      'ainap_ajax_test_feed' );
add_action( 'wp_ajax_ainap_apply_preset',   'ainap_ajax_apply_preset' );
add_action( 'wp_ajax_ainap_get_presets',    'ainap_ajax_get_presets' );

/**
 * STEP 1 — Scrape feeds and build queue (no AI, fast).
 * Applies freshness filter and both duplicate checks before returning.
 */
function ainap_ajax_fetch_queue() {
    check_ajax_referer( 'ainap_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
    @set_time_limit( 60 );

    $settings         = AINAP_Settings::get_all();
    $feeds            = isset( $settings['feeds'] ) ? (array) $settings['feeds'] : array();
    $max_posts        = intval( isset( $settings['max_posts_per_run'] )   ? $settings['max_posts_per_run']   : 3 );
    $freshness_mins   = intval( isset( $settings['freshness_minutes'] )   ? $settings['freshness_minutes']   : 15 );
    $check_title_dupe = ! empty( $settings['check_title_dupes'] );
    $all_items        = array();
    $skipped_old      = 0;
    $skipped_dupe     = 0;

    foreach ( $feeds as $feed_url ) {
        $feed_url = trim( $feed_url );
        if ( empty( $feed_url ) ) continue;
        $items     = AINAP_Scraper::fetch_feed( $feed_url, 5, $freshness_mins );
        $all_items = array_merge( $all_items, $items );
    }

    if ( ! empty( $settings['enable_newsapi'] ) && ! empty( $settings['newsapi_key'] ) ) {
        $topics    = isset( $settings['newsapi_topics'] ) ? $settings['newsapi_topics'] : 'bitcoin,ethereum,cryptocurrency';
        $na_items  = AINAP_Scraper::fetch_newsapi( $settings['newsapi_key'], $topics, 10, $freshness_mins );
        $all_items = array_merge( $all_items, $na_items );
    }

    shuffle( $all_items );

    $queue = array();
    foreach ( $all_items as $item ) {
        if ( count( $queue ) >= $max_posts ) break;

        $link  = isset( $item['link'] )  ? $item['link']  : '';
        $title = isset( $item['title'] ) ? $item['title'] : '';

        // Skip if no link
        if ( empty( $link ) ) continue;

        // Duplicate check by URL
        if ( AINAP_PostCreator::source_exists( $link ) ) {
            $skipped_dupe++;
            continue;
        }

        // Duplicate check by title (catches same story from multiple sources)
        if ( $check_title_dupe && AINAP_PostCreator::title_exists( $title ) ) {
            $skipped_dupe++;
            continue;
        }

        $queue[] = array(
            'title'       => $title,
            'link'        => $link,
            'description' => isset( $item['description'] ) ? $item['description'] : '',
            'content'     => isset( $item['content'] )     ? $item['content']     : '',
            'pub_date'    => isset( $item['pub_date'] )    ? $item['pub_date']    : '',
            'author'      => isset( $item['author'] )      ? $item['author']      : '',
            'image'       => isset( $item['image'] )       ? $item['image']       : '',
            'feed_url'    => isset( $item['feed_url'] )    ? $item['feed_url']    : '',
        );
    }

    wp_send_json_success( array(
        'queue'        => $queue,
        'total'        => count( $queue ),
        'feeds_tried'  => count( $feeds ),
        'skipped_dupe' => $skipped_dupe,
        'freshness'    => $freshness_mins,
    ) );
}

/**
 * STEP 2 — Rewrite + SEO + save ONE article (called per-item by JS).
 */
function ainap_ajax_process_one() {
    check_ajax_referer( 'ainap_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
    @set_time_limit( 120 );

    $item = isset( $_POST['item'] ) ? (array) $_POST['item'] : array();
    if ( empty( $item['title'] ) ) {
        wp_send_json_error( 'Empty item.' );
        return;
    }

    $settings         = AINAP_Settings::get_all();
    $check_title_dupe = ! empty( $settings['check_title_dupes'] );

    // Final duplicate guard (race condition / multiple sources)
    if ( AINAP_PostCreator::source_exists( isset( $item['link'] ) ? $item['link'] : '' ) ) {
        wp_send_json_success( array( 'status' => 'skipped', 'message' => 'URL already imported.' ) );
        return;
    }
    if ( $check_title_dupe && AINAP_PostCreator::title_exists( isset( $item['title'] ) ? $item['title'] : '' ) ) {
        wp_send_json_success( array( 'status' => 'skipped', 'message' => 'Similar title already exists.' ) );
        return;
    }

    $log_data = array(
        'run_time'       => current_time( 'mysql' ),
        'source_url'     => isset( $item['link'] )  ? $item['link']  : '',
        'original_title' => isset( $item['title'] ) ? $item['title'] : '',
        'status'         => 'processing',
        'seo_score'      => 0,
        'aeo_score'      => 0,
    );

    // 1. Rewrite
    $rewritten = AINAP_Rewriter::rewrite( $item, $settings );
    if ( is_wp_error( $rewritten ) ) {
        $log_data['status']        = 'error';
        $log_data['error_message'] = $rewritten->get_error_message();
        ainap_log( $log_data );
        wp_send_json_error( array( 'message' => $rewritten->get_error_message(), 'title' => $log_data['original_title'] ) );
        return;
    }

    // 2. Generate image (only if key configured)
    $image_result  = null;
    $has_image_key = ( ! empty( $settings['stability_api_key'] ) || ! empty( $settings['openai_api_key'] ) );
    if ( ! empty( $settings['generate_images'] ) && $has_image_key ) {
        $image_result = AINAP_ImageGenerator::generate( $rewritten['title'], isset( $rewritten['content_html'] ) ? $rewritten['content_html'] : '', $settings );
    }

    // 3. SEO + AEO
    $seo                   = AINAP_SeoChecker::check( $rewritten );
    $log_data['seo_score'] = $seo['seo_score'];
    $log_data['aeo_score'] = $seo['aeo_score'];

    $rewritten['seo_data']    = $seo;
    $rewritten['image_url']   = $image_result;
    $rewritten['source_link'] = $log_data['source_url'];

    // 4. Save draft
    $post_id = AINAP_PostCreator::create_draft( $rewritten, $settings );
    if ( is_wp_error( $post_id ) ) {
        $log_data['status']        = 'error';
        $log_data['error_message'] = $post_id->get_error_message();
        ainap_log( $log_data );
        wp_send_json_error( array( 'message' => $post_id->get_error_message(), 'title' => $log_data['original_title'] ) );
        return;
    }

    // Mark whether image was generated
    update_post_meta( $post_id, '_ainap_has_image', ( ! empty( $image_result['id'] ) ) ? 1 : 0 );

    $log_data['status']  = 'draft_created';
    $log_data['post_id'] = $post_id;
    ainap_log( $log_data );

    wp_send_json_success( array(
        'status'    => 'draft_created',
        'post_id'   => $post_id,
        'edit_url'  => admin_url( 'post.php?post=' . $post_id . '&action=edit' ),
        'title'     => $rewritten['title'],
        'seo_score' => $seo['seo_score'],
        'aeo_score' => $seo['aeo_score'],
        'has_image' => ! empty( $image_result['id'] ),
        'message'   => 'Draft created: ' . $rewritten['title'],
    ) );
}

/**
 * Generate image for an existing post (called from history log).
 */
function ainap_ajax_generate_image() {
    check_ajax_referer( 'ainap_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
    @set_time_limit( 90 );

    $post_id = intval( isset( $_POST['post_id'] ) ? $_POST['post_id'] : 0 );
    if ( ! $post_id ) {
        wp_send_json_error( 'Invalid post ID.' );
        return;
    }

    $post = get_post( $post_id );
    if ( ! $post ) {
        wp_send_json_error( 'Post not found.' );
        return;
    }

    $settings      = AINAP_Settings::get_all();
    $has_image_key = ( ! empty( $settings['stability_api_key'] ) || ! empty( $settings['openai_api_key'] ) );
    if ( ! $has_image_key ) {
        wp_send_json_error( 'No image API key configured. Add Stability AI or OpenAI key in Settings → API Keys.' );
        return;
    }

    $image_result = AINAP_ImageGenerator::generate( $post->post_title, $post->post_content, $settings );
    if ( is_wp_error( $image_result ) || empty( $image_result['id'] ) ) {
        $msg = is_wp_error( $image_result ) ? $image_result->get_error_message() : 'Image generation returned no data.';
        wp_send_json_error( $msg );
        return;
    }

    AINAP_PostCreator::attach_image( $post_id, $image_result );

    wp_send_json_success( array(
        'post_id'   => $post_id,
        'image_url' => $image_result['url'],
        'message'   => 'Image generated and set as featured image for Post #' . $post_id,
    ) );
}

function ainap_ajax_get_logs() {
    check_ajax_referer( 'ainap_nonce', 'nonce' );
    ainap_create_table();
    global $wpdb;
    $table = $wpdb->prefix . 'ainap_logs';

    // Enrich logs with has_image flag from post meta
    $logs = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY run_time DESC LIMIT 50" );
    foreach ( $logs as $log ) {
        $log->has_image = 0;
        if ( intval( $log->post_id ) > 0 ) {
            $log->has_image = intval( get_post_meta( intval( $log->post_id ), '_ainap_has_image', true ) );
            // Also check if featured image is actually set
            if ( has_post_thumbnail( intval( $log->post_id ) ) ) {
                $log->has_image = 1;
            }
        }
    }
    wp_send_json_success( $logs );
}

function ainap_ajax_save_settings() {
    check_ajax_referer( 'ainap_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
    $settings = isset( $_POST['settings'] ) ? (array) $_POST['settings'] : array();
    AINAP_Settings::save( $settings );
    // Reschedule cron if interval changed
    AINAP_Scheduler::reschedule();
    wp_send_json_success( 'Settings saved.' );
}

function ainap_ajax_test_feed() {
    check_ajax_referer( 'ainap_nonce', 'nonce' );
    $url   = isset( $_POST['url'] ) ? sanitize_url( $_POST['url'] ) : '';
    $items = AINAP_Scraper::fetch_feed( $url, 3, 0 ); // no freshness filter for test
    wp_send_json_success( $items );
}

function ainap_ajax_apply_preset() {
    check_ajax_referer( 'ainap_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
    $niche  = isset( $_POST['niche'] ) ? sanitize_text_field( $_POST['niche'] ) : '';
    $result = AINAP_Settings::apply_preset( $niche );
    if ( $result ) {
        $presets = AINAP_Settings::get_presets();
        $preset  = $presets[ $niche ];
        wp_send_json_success( array(
            'message'    => "Preset '{$preset['label']}' applied!",
            'settings'   => AINAP_Settings::get_all(),
            'categories' => $preset['categories'],
            'feeds'      => $preset['feeds'],
        ) );
    } else {
        wp_send_json_error( 'Invalid preset.' );
    }
}

function ainap_ajax_get_presets() {
    check_ajax_referer( 'ainap_nonce', 'nonce' );
    wp_send_json_success( AINAP_Settings::get_presets() );
}

// ── Cron ─────────────────────────────────────────────────────────────────────
add_action( 'ainap_cron_hook', 'ainap_cron_process' );

function ainap_cron_process() {
    @set_time_limit( 300 );

    $settings         = AINAP_Settings::get_all();
    $feeds            = isset( $settings['feeds'] ) ? (array) $settings['feeds'] : array();
    $max_posts        = intval( isset( $settings['max_posts_per_run'] )  ? $settings['max_posts_per_run']  : 3 );
    $freshness_mins   = intval( isset( $settings['freshness_minutes'] )  ? $settings['freshness_minutes']  : 15 );
    $check_title_dupe = ! empty( $settings['check_title_dupes'] );
    $all_items        = array();

    foreach ( $feeds as $feed_url ) {
        $feed_url = trim( $feed_url );
        if ( empty( $feed_url ) ) continue;
        $items     = AINAP_Scraper::fetch_feed( $feed_url, 5, $freshness_mins );
        $all_items = array_merge( $all_items, $items );
    }

    if ( ! empty( $settings['enable_newsapi'] ) && ! empty( $settings['newsapi_key'] ) ) {
        $topics    = isset( $settings['newsapi_topics'] ) ? $settings['newsapi_topics'] : 'bitcoin,ethereum,cryptocurrency';
        $na_items  = AINAP_Scraper::fetch_newsapi( $settings['newsapi_key'], $topics, 10, $freshness_mins );
        $all_items = array_merge( $all_items, $na_items );
    }

    shuffle( $all_items );
    $processed = 0;

    foreach ( $all_items as $item ) {
        if ( $processed >= $max_posts ) break;

        $link  = isset( $item['link'] )  ? $item['link']  : '';
        $title = isset( $item['title'] ) ? $item['title'] : '';

        if ( empty( $link ) ) continue;
        if ( AINAP_PostCreator::source_exists( $link ) ) continue;
        if ( $check_title_dupe && AINAP_PostCreator::title_exists( $title ) ) continue;

        $rewritten = AINAP_Rewriter::rewrite( $item, $settings );
        if ( is_wp_error( $rewritten ) ) {
            ainap_log( array( 'run_time' => current_time( 'mysql' ), 'source_url' => $link, 'original_title' => $title, 'status' => 'error', 'error_message' => $rewritten->get_error_message(), 'seo_score' => 0, 'aeo_score' => 0 ) );
            continue;
        }

        $has_image_key = ( ! empty( $settings['stability_api_key'] ) || ! empty( $settings['openai_api_key'] ) );
        $image_result  = null;
        if ( ! empty( $settings['generate_images'] ) && $has_image_key ) {
            $image_result = AINAP_ImageGenerator::generate( $rewritten['title'], isset( $rewritten['content_html'] ) ? $rewritten['content_html'] : '', $settings );
        }

        $seo                   = AINAP_SeoChecker::check( $rewritten );
        $rewritten['seo_data']    = $seo;
        $rewritten['image_url']   = $image_result;
        $rewritten['source_link'] = $link;

        $post_id = AINAP_PostCreator::create_draft( $rewritten, $settings );
        update_post_meta( is_wp_error( $post_id ) ? 0 : $post_id, '_ainap_has_image', ( ! empty( $image_result['id'] ) ) ? 1 : 0 );

        ainap_log( array(
            'run_time'       => current_time( 'mysql' ),
            'source_url'     => $link,
            'original_title' => $title,
            'status'         => is_wp_error( $post_id ) ? 'error' : 'draft_created',
            'post_id'        => is_wp_error( $post_id ) ? 0 : $post_id,
            'seo_score'      => $seo['seo_score'],
            'aeo_score'      => $seo['aeo_score'],
            'error_message'  => is_wp_error( $post_id ) ? $post_id->get_error_message() : '',
        ) );
        $processed++;
    }
}

function ainap_log( $data ) {
    ainap_create_table();
    global $wpdb;
    $wpdb->insert( $wpdb->prefix . 'ainap_logs', $data );
}
